C:\Projects\14112016_Replay\MDF_6_0_0_1164_2016_WW6_Internal\

# first line must point to the compiler
# second line must point to grits
# third line must point to the location that Isaasm & Isapat located
#
# make sure there are no spaces in the end of the lines!!!