/*===================== begin_copyright_notice ==================================

INTEL CONFIDENTIAL
Copyright 2012-2014
Intel Corporation All Rights Reserved.

The source code contained or described herein and all documents related to the
source code ("Material") are owned by Intel Corporation or its suppliers or
licensors. Title to the Material remains with Intel Corporation or its suppliers
and licensors. The Material contains trade secrets and proprietary and confidential
information of Intel or its suppliers and licensors. The Material is protected by
worldwide copyright and trade secret laws and treaty provisions. No part of the
Material may be used, copied, reproduced, modified, published, uploaded, posted,
transmitted, distributed, or disclosed in any way without Intel�s prior express
written permission.

No license under any patent, copyright, trade secret or other intellectual
property right is granted to or conferred upon you by disclosure or delivery
of the Materials, either expressly, by implication, inducement, estoppel or
otherwise. Any license under such intellectual property rights must be express
and approved by Intel in writing.

======================= end_copyright_notice ==================================*/

// Comment to remove debug instructions
//#define DEBUG

#include <cm/cm.h>
#include <cm/genx_sampler.h>

#define CHANNEL_A					3
#define CHANNEL_R					2
#define CHANNEL_G					1
#define CHANNEL_B					0


#define CHANNEL_A_16BIT				3
#define CHANNEL_B_16BIT				2
#define CHANNEL_G_16BIT				1
#define CHANNEL_R_16BIT				0

#define BLOCK_SIZE_WIDTH			16
#define BLOCK_SIZE_HEIGHT			16

#define PIXEL_PRECISION_16_BITS		(1<<0)
#define PIXEL_PRECISION_8_BITS		(1<<1)

#define NUM_ELEMENT_PIXEL			(4)

// location of the coefficients in the vector
#define U0						0  //x
#define DU						1
#define DDU						2

#define V0						3  //y
#define DV						4
#define DDV						5

#define MAX(a,b)				(((a)>(b))? (a) : (b))
#define MIN(a,b)				(((a)<(b))? (a) : (b))




template< uint W, uint H, typename T >
_GENX_  void 
	inline  lens_correction_aux(	SamplerIndex				sampler_config, 
	SurfaceIndex				src_surf, 
	matrix_ref<float, 3, 6>		args,
	AVSExecMode					execMode,
	matrix_ref<T, H, W * 4>		rgba,
	const char bit_mode_flag,	// 16 or 8 bits 
	ushort						correction_type,
	ushort						alpha_enable,
	ushort						alpha

	)
{




	const short VerticalBlockNumber = 0;		
	const int GroupID = get_thread_origin_y();

	if(correction_type == 0)
	{
		// LGC - combined channels

		matrix<ushort, 4, W * H > writeback_rgba;

		cm_avs_sampler( writeback_rgba, 
			CM_ABGR_ENABLE, 
			src_surf, 
			sampler_config, 
			args[0][U0],
			args[0][V0],
			args[0][DU],
			args[0][DV],
			args[0][DDU],
			GroupID , 
			VerticalBlockNumber, 
			CM_16_FULL, 
			args[0][DDV],
			execMode, 
			true );

		if ( bit_mode_flag & PIXEL_PRECISION_8_BITS )
		{	

			writeback_rgba.template select<1,1,W*H,1>(0,0) = cm_add<ushort>( writeback_rgba.template select<1,1,W*H,1>(0,0), (1<<7), SAT);
			writeback_rgba.template select<1,1,W*H,1>(1,0) = cm_add<ushort>( writeback_rgba.template select<1,1,W*H,1>(1,0), (1<<7), SAT );
			writeback_rgba.template select<1,1,W*H,1>(2,0) = cm_add<ushort>( writeback_rgba.template select<1,1,W*H,1>(2,0), (1<<7), SAT );
			writeback_rgba.template select<1,1,W*H,1>(3,0) = cm_add<ushort>( writeback_rgba.template select<1,1,W*H,1>(3,0), (1<<7), SAT );
			rgba.template select<H,1,W,4>(0,CHANNEL_R)	= writeback_rgba.template select<1,1,W*H,1>(0,0)  >> 8 ;
			rgba.template select<H,1,W,4>(0,CHANNEL_G)	= writeback_rgba.template select<1,1,W*H,1>(1,0)  >> 8 ;
			rgba.template select<H,1,W,4>(0,CHANNEL_B)	= writeback_rgba.template select<1,1,W*H,1>(2,0) >> 8 ;
			rgba.template select<H,1,W,4>(0,CHANNEL_A)	= alpha_enable ? (T)alpha : writeback_rgba.template select<1,1,W*H,1>(3,0) >> 8 ;
		}

		if ( bit_mode_flag & PIXEL_PRECISION_16_BITS )
		{
			rgba.template select<H,1,W,4>(0,CHANNEL_R_16BIT) = writeback_rgba.template select<1,1,W*H,1>(0,0);
			rgba.template select<H,1,W,4>(0,CHANNEL_G_16BIT) = writeback_rgba.template select<1,1,W*H,1>(1,0);
			rgba.template select<H,1,W,4>(0,CHANNEL_B_16BIT) = writeback_rgba.template select<1,1,W*H,1>(2,0);
			rgba.template select<H,1,W,4>(0,CHANNEL_A_16BIT) = alpha_enable ? (T)alpha : (T)0;	
		}
	}
	else  //CA correction
	{

		matrix<ushort, 1, W * H > Writeback_r;
		matrix<ushort, 1, W * H > Writeback_g;
		matrix<ushort, 2, W * H > Writeback_ba;

		// Red
		cm_avs_sampler( Writeback_r, 
			CM_R_ENABLE, 
			src_surf, 
			sampler_config, 
			args[0][U0],
			args[0][V0],
			args[0][DU],
			args[0][DV],
			args[0][DDU],
			GroupID , 
			VerticalBlockNumber, 
			CM_16_FULL, 
			args[0][DDV],
			execMode, 
			true );

		// Green
		cm_avs_sampler( Writeback_g, 
			CM_G_ENABLE, 
			src_surf, 
			sampler_config, 
			args[1][U0],
			args[1][V0],
			args[1][DU],
			args[1][DV],
			args[1][DDU],
			GroupID , 
			VerticalBlockNumber, 
			CM_16_FULL, 
			args[1][DDV],
			execMode, 
			true );

		// Blue & Alpha
		cm_avs_sampler( Writeback_ba, 
			CM_AB_ENABLE, 
			src_surf, 
			sampler_config, 
			args[2][U0],
			args[2][V0],
			args[2][DU],
			args[2][DV],
			args[2][DDU],
			GroupID , 
			VerticalBlockNumber, 
			CM_16_FULL, 
			args[2][DDV],
			execMode, 
			true );

		if ( bit_mode_flag & PIXEL_PRECISION_8_BITS )
		{	

			Writeback_r.template select<1,1,W*H,1>(0,0)  =	cm_add<ushort>( Writeback_r.template select<1,1,W*H,1>(0,0), (1<<7), SAT);
			Writeback_g.template select<1,1,W*H,1>(0,0)  =	cm_add<ushort>( Writeback_g.template select<1,1,W*H,1>(0,0), (1<<7), SAT );
			Writeback_ba.template select<1,1,W*H,1>(0,0) =	cm_add<ushort>( Writeback_ba.template select<1,1,W*H,1>(0,0), (1<<7), SAT );
			Writeback_ba.template select<1,1,W*H,1>(1,0) =	cm_add<ushort>( Writeback_ba.template select<1,1,W*H,1>(1,0), (1<<7), SAT );

			rgba.template select<H,1,W,4>(0,CHANNEL_R)	= Writeback_r.template select<1,1,W*H,1>(0,0)  >> 8 ;
			rgba.template select<H,1,W,4>(0,CHANNEL_G)	= Writeback_g.template select<1,1,W*H,1>(0,0)  >> 8 ;
			rgba.template select<H,1,W,4>(0,CHANNEL_B)	= Writeback_ba.template select<1,1,W*H,1>(0,0) >> 8 ;
			if (alpha_enable)
				rgba.template select<H,1,W,4>(0,CHANNEL_A)	= (T)alpha;
			else 
				rgba.template select<H,1,W,4>(0,CHANNEL_A)	= Writeback_ba.template select<1,1,W*H,1>(1,0) >> 8 ;
		}

		if ( bit_mode_flag & PIXEL_PRECISION_16_BITS )
		{
			rgba.template select<H,1,W,4>(0,CHANNEL_R_16BIT)	= Writeback_r;
			rgba.template select<H,1,W,4>(0,CHANNEL_G_16BIT)	= Writeback_g;
			rgba.template select<H,1,W,4>(0,CHANNEL_B_16BIT)	= Writeback_ba.row(0);
			if (alpha_enable)
				rgba.template select<H,1,W,4>(0,CHANNEL_A_16BIT)	= (T)alpha;
			else
				rgba.template select<H,1,W,4>(0,CHANNEL_A_16BIT)	= (T)0;	
		}
	}


}
/*
Scaling factor calculation according to m_max_value and m_min_value values for x and y
*/
_GENX_  float 
	inline  apply_scaling(vector_ref <float, 2> m_max_value, vector_ref <float, 2> m_min_value, vector_ref <float, 2> norm_y_x)
{
	//float test, test2, 
	vector<float,2> test; //test and test2 
	//float test_final;
	// center_final;
	//float delta_x, delta_y;
	vector <float, 2> delta_y_x = 0.5f;
	float coeff = 0.5f; 
	vector <ushort, 2> norm_mask_inc =  ((norm_y_x-coeff) > 0);
	vector <ushort, 2> norm_mask_dec =  ((norm_y_x-coeff) < 0);
	/*
	if (m_norm_yc!=0.5)
	delta_y = (m_norm_yc > 0.5) ? (1-m_norm_yc):m_norm_yc;
	if (m_norm_xc!=0.5)
	delta_x = (m_norm_xc > 0.5) ? (1-m_norm_xc):m_norm_xc;
	*/
	if(norm_y_x[0] != coeff && norm_y_x[1] != coeff) // m_norm_yc!=0.5 && m_norm_xc!=0.5
	{
		delta_y_x.merge((1.0f-norm_y_x), norm_y_x, norm_mask_inc );

		//vertical y

		/*
		if (m_norm_yc!=0.5)
		test = (m_norm_yc<0.5)?m_min_y0_value:m_max_y0_value;
		else if ((m_norm_yc-m_min_y0_value) < (m_max_y0_value-m_norm_yc))
		test = m_max_y0_value;
		else
		test = m_min_y0_value;

		if (m_norm_xc!=0.5)
		test2 = (m_norm_xc<0.5)?m_min_x0_value:m_max_x0_value;
		else if ((m_norm_xc-m_min_x0_value) < (m_max_x0_value-m_norm_xc))
		test2 = m_max_x0_value;
		else
		test2 = m_min_x0_value;
		*/
		test.merge(m_min_value, m_max_value, norm_mask_dec);
	}
	else {
		vector <float, 2> dif_min = (norm_y_x-m_min_value) ;
		vector <float, 2> dif_max = (m_max_value-norm_y_x);
		vector <ushort, 2> dif_mask = (dif_min < dif_max);
		test.merge(m_max_value, m_min_value, dif_mask);
	}


	/*
	if (abs(test-m_norm_yc)/delta_y > abs(test2-m_norm_xc)/delta_x)
	{
	test_final = test;
	center_final = m_norm_yc;
	}
	else if (abs(test-m_norm_yc)/delta_y < abs(test2-m_norm_xc)/delta_x)
	{
	test_final = test2;
	center_final = m_norm_xc;
	}	
	else
	{
	test_final = (delta_y>delta_x)?test2:test;
	center_final = (delta_y>delta_x)?m_norm_yc:m_norm_xc;
	}
	*/
	vector <float, 1> test_final; 
	vector <float, 1> center_final;
	vector <float, 2> tempa = test-norm_y_x;
	vector <float, 2> abs_diff =  cm_abs<float>(tempa*2);

	float msk = (abs_diff[0] - abs_diff[1]);


	if(msk == 0)
	{	
		ushort mask2 = (delta_y_x[0]>delta_y_x[1]);
		test_final.merge(test[0], test[1],  mask2);
		center_final.merge(norm_y_x[0], norm_y_x[1], mask2);
	}
	else {
		test_final.merge(test[0], test[1],  msk>0);
		center_final.merge(norm_y_x[0], norm_y_x[1], msk>0);
	}
	//
	//float select_center, select_center2;
	vector <float, 1> scale_factor;
	//vector <float, 1> mask_mm = ((m_min_value == 0) && (m_max_value == 1));
	ushort mask_mm = (m_min_value[0]==0 && m_max_value[0]==1 && m_min_value[1]== 0 && m_max_value[1]==1);
	//ushort  mask_center =  (center_final>0.5);

	vector<float,1> tempp = 1.0000000000f;
	tempp = tempp - center_final;
	vector<float,1> a_select_center = tempp*2; // /0.5;
	vector <float,1> a_select_center2 = center_final*2; ///0.5;
	vector <float,1> temp_a = test_final-center_final;
	vector <float,1> b_abs = cm_abs<float>(temp_a);
	float temp_b = cm_inv(b_abs[0]);
	vector <float,1> b_select_center;
	b_select_center[0] = tempp[0] * temp_b; 
	vector <float,1> b_select_center2;
	b_select_center2[0] = center_final[0] * temp_b; 

	scale_factor.merge(a_select_center, a_select_center2, (center_final[0]>coeff && mask_mm));
	scale_factor.merge(b_select_center, b_select_center2, (center_final[0]>coeff && !mask_mm));

	/*
	if (m_min_value[0]==0 && m_max_value[0]==1 && m_min_value[1]== 0 && m_max_value[1]==1)
	scale_factor = ((center_final>0.5)?(1-center_final):center_final)/0.5;
	else
	scale_factor = ((center_final>0.5)?(1-center_final):center_final)/abs(test_final-center_final);//min(min_val, max_val);
	*/
	return (scale_factor[0]);
}
#ifdef DEBUG 
_GENX_  void 
	write_sampler_debug(	SurfaceIndex		dst_surf,
	vector<float,6>		sampler_args,
	uint				h_pos,
	uint				v_pos )
{
	write( dst_surf, h_pos * 24, v_pos, sampler_args );
}
#endif
/*--------------------------------------------------------------------------
* camera_pipe kernel - main 
*
* Description:
* 
*		A Combined kernel that performs lens correction and chroma aberration.
*
* Parameters:
*
*	SamplerIndex sampler_config:		Index of AVS sampler to use
*
*	SurfaceIndex src_surf:				Index of input surface
*
*	SurfaceIndex dst_surf:				Index of output surface
*	SamplerIndex sample_params:			Index of input sampler parameters surface - output from CalcParams kernel
*
*	SurfaceIndex sample_statistics:		Index of input sampler statistics surface - output from CalcParams kernel
*
*
*	ushort	height:						Input surface height [pixel]	
*	ushort	width:						Input surface width  [pixel]
*
*  ushort	correction_type:			1 -	CA:  separate coefficients are applied to each of the color channels 
*										0 -	GLC: in this case the first set of coefficients are applied to all color 
*										channels
*	uchar	block_size:					Block size to be used by the AVS Sampler.
*											�	16x4:		1				(default)
*											�	8x4:		2
*											�	4x4:		4
*
*	uchar	pixel_precision:			Input & output color depth.
*											�	16bit (4*16):		1		(default)
*											�	8bit   (4*8):		2
*
*	ushort		alpha_overwrite:
*	ushort		alpha_value:
*	ushort		scaling_enable:			Apply scaling factor calculation.				
*	float		m_norm_xc:				The position of the principal point relative to the width of the image ( 0 - 1.0) 
*  float		m_norm_yc:				The position of the principal point relative to the height of the image ( 0 - 1.0)		
*
* Returns:    N/A
*
*--------------------------------------------------------------------------*/
extern "C" _GENX_MAIN_  void camera_pipe	(	
	SamplerIndex		sampler_config, 
	SurfaceIndex		src_surf,					
	SurfaceIndex		dst_surf,
	SurfaceIndex		sample_params,
	SurfaceIndex		sample_statistics,

	ushort				height,
	ushort				width,
	ushort				correction_type,
	uchar				block_size,
	uchar				pixel_precision,
	ushort				alpha_overwrite,
	ushort				alpha_value,
	ushort				scaling_enable,

	float				m_norm_xc, // R1.5					- offset 52
	float				m_norm_yc // R1.6					- offset 56
	)
{

	/* 
	* Pay attention we use the values of the bit field in order to calculate the width.
	* This is not a good practice but save couple of instructions. 
	* In case the values of the bit field "block_size" are changed - one should make sure this
	* piece of code is correct. 
	*/
	ushort blockWidth = 16 / block_size;
	const ushort blockHeight = 4; // all the supported blocks has height of 4

	ushort numBlockWidth = BLOCK_SIZE_WIDTH / blockWidth;
	const ushort numBlockHeight = BLOCK_SIZE_HEIGHT / blockHeight; // all the supported blocks has height of 4

	matrix<ushort, BLOCK_SIZE_HEIGHT, NUM_ELEMENT_PIXEL * BLOCK_SIZE_WIDTH> rgba16;  // 16 rows of 16 pixels each has 4 elements
	matrix_ref<uchar, BLOCK_SIZE_HEIGHT, NUM_ELEMENT_PIXEL * BLOCK_SIZE_WIDTH> rgba8 
		= rgba16.format<uchar, BLOCK_SIZE_HEIGHT, NUM_ELEMENT_PIXEL * BLOCK_SIZE_WIDTH * 2>().select< BLOCK_SIZE_HEIGHT, 1, NUM_ELEMENT_PIXEL * BLOCK_SIZE_WIDTH, 1>(0,0);  

	uint h_pos = get_thread_origin_x();
	uint v_pos = get_thread_origin_y();

	matrix <float,3, 6> sampler_args;
	vector <float, 6> m_max_value;
	vector <float, 6> m_min_value;

	float scale_r;
	float scale_g;
	float scale_b;


	//scaling!
	if(scaling_enable)
	{
		vector< int, 6 > max_values;
		vector< int, 6 > min_values;

		//if((h_pos == 0) && (v_pos == 0))
		//{
		read( sample_statistics, 0, max_values );
		read( sample_statistics, 32, min_values );

		vector<float, 6> m_max_value = max_values;
		m_max_value *= cm_inv(1000000000.0f);
		vector<float, 6> m_min_value = min_values;
		m_min_value *= cm_inv(1000000000.0f);
		vector <float, 2> norm_y_x;
		norm_y_x[0] = m_norm_yc;
		norm_y_x[1] = m_norm_xc;

		scale_r =
			apply_scaling(m_max_value.select<2,1>(0), m_min_value.select<2,1>(0), norm_y_x);

		if(correction_type)
		{
			scale_g =
				apply_scaling(m_max_value.select<2,1>(2), m_min_value.select<2,1>(2), norm_y_x);

			scale_b =
				apply_scaling(m_max_value.select<2,1>(4), m_min_value.select<2,1>(4), norm_y_x);

			scale_r = MIN(scale_r,scale_g);
			scale_r = MIN(scale_r,scale_b);
			//m_scale_factor = min(min(scale_factorR, scale_factorG), scale_factorB);
			//}
		}

	}

	for ( uint i = 0; i < numBlockHeight; ++i )	// all the supported blocks has height of 4
	{
		for( uint j = 0; j < numBlockWidth; ++j )
		{
			uint x_pos = (h_pos * BLOCK_SIZE_WIDTH) + (j * blockWidth);
			uint y_pos = (v_pos * BLOCK_SIZE_HEIGHT) + (i * blockHeight);

			read( sample_params, (x_pos/blockWidth) * 24, y_pos/ blockHeight, sampler_args.row(0) );
			if(scaling_enable) {
				sampler_args[0][0] = (sampler_args[0][0] - m_norm_xc)*scale_r +  m_norm_xc;	//u0
				sampler_args[0][3] = (sampler_args[0][3] - m_norm_yc)*scale_r +  m_norm_yc;   //v0
				sampler_args[0][1] *= scale_r;			//du
				sampler_args[0][4] *= scale_r;			//dv
			}
			sampler_args[0][DV] = MAX(sampler_args[0][DV],0);
			sampler_args[0][DV] = MIN(sampler_args[0][DV],1);
			sampler_args[0][DU] = MAX(sampler_args[0][DU],0);
			sampler_args[0][DU] = MIN(sampler_args[0][DU],1);
#ifdef DEBUG 
			write_sampler_debug(sample_params,	sampler_args.row(0), x_pos / blockWidth, y_pos / blockHeight);
#endif

			if(correction_type)
			{
				uint g_offset = ((height / blockHeight) + 1)>>1;
				g_offset <<= 1;
				read( sample_params, (x_pos/blockWidth) * 24, y_pos/ blockHeight + g_offset  , sampler_args.row(1) );
				read( sample_params, (x_pos/blockWidth) * 24, y_pos/ blockHeight + g_offset*2, sampler_args.row(2) );
				if(scaling_enable) {
					sampler_args[1][0] = (sampler_args[1][0] - m_norm_xc)*scale_r +  m_norm_xc;	//u0
					sampler_args[1][3] = (sampler_args[1][3] - m_norm_yc)*scale_r +  m_norm_yc;   //v0
					sampler_args[1][1] *= scale_r;			//du
					sampler_args[1][4] *= scale_r;			//dv

					sampler_args[1][DV] = MAX(sampler_args[0][DV],0);
					sampler_args[1][DV] = MIN(sampler_args[0][DV],1);
					sampler_args[1][DU] = MAX(sampler_args[0][DU],0);
					sampler_args[1][DU] = MIN(sampler_args[0][DU],1);
					sampler_args[2][0] = (sampler_args[2][0] - m_norm_xc)*scale_r +  m_norm_xc;	//u0
					sampler_args[2][3] = (sampler_args[2][3] - m_norm_yc)*scale_r +  m_norm_yc;   //v0
					sampler_args[2][1] *= scale_r;			//du
					sampler_args[2][4] *= scale_r;			//dv
					sampler_args[2][DV] = MAX(sampler_args[0][DV],0);
					sampler_args[2][DV] = MIN(sampler_args[0][DV],1);
					sampler_args[2][DU] = MAX(sampler_args[0][DU],0);
					sampler_args[2][DU] = MIN(sampler_args[0][DU],1);
				}
			}

			if ( PIXEL_PRECISION_8_BITS & pixel_precision )
			{
				if ( blockWidth & 0x10 )  
				{
					// blockWidth == 16
					lens_correction_aux<16,4,uchar>(	
						sampler_config, 
						src_surf, 
						sampler_args,
						CM_AVS_16x4,
						rgba8.select<4,1,NUM_ELEMENT_PIXEL * 16,1>( i * 4, j*16 * NUM_ELEMENT_PIXEL ),
						PIXEL_PRECISION_8_BITS, 
						correction_type,
						alpha_overwrite,
						alpha_value);

				}
				else if ( blockWidth & 0x8 )
				{
					// blockWidth == 8 

					lens_correction_aux<8,4,uchar>(	
						sampler_config, 
						src_surf, 
						sampler_args,
						CM_AVS_8x4,
						rgba8.select<4,1,NUM_ELEMENT_PIXEL * 8,1>( i * 4, j * 8 * NUM_ELEMENT_PIXEL ),
						PIXEL_PRECISION_8_BITS, 
						correction_type,
						alpha_overwrite,
						alpha_value);
				}
				else
				{
					// blockWidth  == 4
					lens_correction_aux<4,4,uchar>(	
						sampler_config, 
						src_surf, 
						sampler_args,
						CM_AVS_4x4,
						rgba8.select<4,1,NUM_ELEMENT_PIXEL * 4,1>( i * 4, j * 4 * NUM_ELEMENT_PIXEL ),
						PIXEL_PRECISION_8_BITS, 
						correction_type,
						alpha_overwrite,
						alpha_value);
				}

			} // if ( PIXEL_PRECISION_8_BITS == pixel_precision )

			else
			{
				// pixel_precision == PIXEL_PRECISION_16_BITS 

				if ( blockWidth & 0x10 )  
				{
					// blockWidth == 16

					lens_correction_aux<16,4,ushort>(	
						sampler_config, 
						src_surf, 
						sampler_args,
						CM_AVS_16x4,
						rgba16.select<4,1,NUM_ELEMENT_PIXEL * 16,1>( i * 4, j * 16 * NUM_ELEMENT_PIXEL ),
						PIXEL_PRECISION_16_BITS, 
						correction_type,
						alpha_overwrite,
						alpha_value);
				}
				else if ( blockWidth & 0x8 )
				{
					// blockWidth == 8 

					lens_correction_aux<8,4,ushort>(	
						sampler_config, 
						src_surf, 
						sampler_args,
						CM_AVS_8x4,
						rgba16.select<4,1,NUM_ELEMENT_PIXEL * 8,1>( i * 4, j * 8 * NUM_ELEMENT_PIXEL ),
						PIXEL_PRECISION_16_BITS,
						correction_type,
						alpha_overwrite,
						alpha_value
						);
				}
				else
				{
					// blockWidth  == 4

					lens_correction_aux<4,4,ushort>(	
						sampler_config, 
						src_surf, 
						sampler_args,
						CM_AVS_4x4,
						rgba16.select<4,1,NUM_ELEMENT_PIXEL * 4,1>( i * 4, j * 4 * NUM_ELEMENT_PIXEL ),
						PIXEL_PRECISION_16_BITS, 
						correction_type, alpha_overwrite,
						alpha_value );
				}
			}

		}

	}

	v_pos *= BLOCK_SIZE_HEIGHT;
	h_pos *= NUM_ELEMENT_PIXEL * BLOCK_SIZE_WIDTH;	// 4 channels * 16 pixels - byte per channel

	if ( PIXEL_PRECISION_8_BITS & pixel_precision )
	{
		// Output block 16x16 pixels = (16*4)*16 bytes.  32bits per pixel.
		write(dst_surf, h_pos,		v_pos, rgba8.select<8,1,32,1>(0,0)); 
		write(dst_surf, h_pos + 32, v_pos, rgba8.select<8,1,32,1>(0,32)); 

		write(dst_surf, h_pos,		v_pos + 8, rgba8.select<8,1,32,1>(8,0)); 
		write(dst_surf, h_pos + 32, v_pos + 8, rgba8.select<8,1,32,1>(8,32));  
	}
	else
	{
		// PIXEL_PRECISION_16_BITS == pixel_precision
		h_pos *= 2;

		matrix_ref<uchar,BLOCK_SIZE_HEIGHT,NUM_ELEMENT_PIXEL * BLOCK_SIZE_WIDTH * 2> ref_rgba 
			= rgba16.format<uchar, BLOCK_SIZE_HEIGHT, NUM_ELEMENT_PIXEL * BLOCK_SIZE_WIDTH * 2>();

		// Output block 16x16 pixels = (16*4*2)*16 bytes. 64 bits per pixel.
		write(dst_surf, h_pos,		v_pos, ref_rgba.select<8,1,32,1>(0,0)); 
		write(dst_surf, h_pos + 32, v_pos, ref_rgba.select<8,1,32,1>(0,32)); 
		write(dst_surf, h_pos + 64, v_pos, ref_rgba.select<8,1,32,1>(0,64)); 
		write(dst_surf, h_pos + 96, v_pos, ref_rgba.select<8,1,32,1>(0,96)); 

		write(dst_surf, h_pos,		v_pos + 8, ref_rgba.select<8,1,32,1>(8,0)); 
		write(dst_surf, h_pos + 32, v_pos + 8, ref_rgba.select<8,1,32,1>(8,32)); 
		write(dst_surf, h_pos + 64, v_pos + 8, ref_rgba.select<8,1,32,1>(8,64)); 
		write(dst_surf, h_pos + 96, v_pos + 8, ref_rgba.select<8,1,32,1>(8,96)); 
	}	

}
