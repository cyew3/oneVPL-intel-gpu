/**             
***
*** Copyright  (C) 1985-2012 Intel Corporation. All rights reserved.
***
*** The information and source code contained herein is the exclusive
*** property of Intel Corporation. and may not be disclosed, examined
*** or reproduced in whole or in part without explicit written authorization
*** from the company.
***
*** ----------------------------------------------------------------------------
**/ 

#ifndef __HOST_H_
#define __HOST_H_

#include <sys/stat.h>
#include <assert.h>
#include <iostream>
#include <limits>
#include <stdio.h>
#include <math.h>
#include <string>


#include <cm/genx_dataport.h>
#include <cm/genx_sampler.h>
#include "cm_rt.h"

#define MIN(a,b)		((a) < (b))? (a):(b)

// basic exception object
class Exception
{

public:

	Exception( std::string msg ):
	  _msg(msg)
	{
		// empty on purpose
	}

	const std::string& what()
	{
		return _msg;
	}

protected:
	std::string					_msg;		// the message that describe the exception error

};

// Default sizes 
#define MAX_KERNEL_MEDIA_SURFACES				(10)
#define MAX_KERNEL_BUFFERS						(10)
#define MAX_KERNEL_CURBE_ARGUMENTS				(20)
#define MAX_KERNEL_SAMPLERS_ARGUMENTS			(10)

typedef enum
{
	ELEMENT_SIZE_BYTE							= 0,
	ELEMENT_SIZE_WORD							= 1,

} element_size_t;

// the context that defines a program of kernels
typedef struct
{
	CmDevice*					pCmDev;						// the CM device 
	CmProgram*					program;					// the program that contains the kernel
	const char*					program_path;				// path to the program file of the kernel
	void*						pCommonISACode;				// buffer for the source code
	CmTask*						pKernelArray;				// list of kernels of the device
	CmQueue*					pCmQueue;					// Queue of tasks
	
} device_context_t;

// direction of buffers
typedef enum
{
	BUFFER_DIRECTION_INPUT					= 0,
	BUFFER_DIRECTION_OUTPUT					= 1

} buffer_direction_t;

// flags that indicates whether the buffer should be loaded/read in a special manner
typedef enum
{
	NONE									= 0,
	RGB_2_RGBA								= (1<<0),
	RGBA_2_RGB								= (1<<2),
	INVERSE									= (1<<3),		// workaround for BMP files

} buffers_flag_t;

/*
 *  Media Walker surfaces - this struct should be filled partialy by the 
 *	user before calling to alloc_media_surfaces and write_data_to_2D_surface 
 */
typedef struct
{
	// =============================>
	// to be filled by the user
	// =============================>
	uint						kernel_arg_indx;	/*< the number of the argument in the 
														kernel arguments list					>*/

	const char*					file_path;			/*< path to a file that it's contant 
														should be loaded to the surface
														in case set to NULL a host buffer must be 
														supplied								>*/

	void*						host_buff;			/*<	an optional way to load a data to the 
														surface (file path should be set to NULL)>*/

	CM_SURFACE_FORMAT			surface_type;		//	the CM type of the surface

	uint						width;				//	width of the surface (pixels)
	uint						height;				//	height of the surface (pixels)

	uint						offset;				/*< offset from the beggining of the 
														file to start the reading				 >*/
	uint						size;				//	the size of the buffer

	buffer_direction_t			direction;			//	indicates the direction of the surface

	uint						flags;				/*<	indicates whether the data should 
														be read/written in a special manner
														buffers_flag_t							>*/
	
	element_size_t				element_size;		// size each element in the buffers

	// ==========================================>
	// Automaticlly filled by the host_template
	// ==========================================>
	CmSurface2D*				handle;				//	CM surface handle		
	void *						pSysMemSrc;			//	media walker buffer
	SurfaceIndex*				surf_indx;			//	CM surface index 

} media_surface_info_t;

// Sampler8x8 media surface
typedef struct
{
	CmSurface2D*				handle;
	SurfaceIndex*				surf_indx;
	uint						kernel_arg_indx;
	const char*					file_path;
	void*						host_buff;
	CM_SURFACE_FORMAT			surface_type;
	uint						width;
	uint						height;
	uint						offset;
	uint						size;
	uint						flags;	// buffers_flag_t
	element_size_t				element_size;		// size each element in the buffers
	
} sampler8x8_surface_info_t;

typedef struct
{
	CmSampler*					pSampler;
	CM_SAMPLER_STATE			sampleState;
	SamplerIndex*				sampler_indx;
	uint						kernel_arg_indx;		// the index in the kernel arguments list

} sampler_info_t;

typedef struct
{
	CmSampler8x8*				pSampler8x8;
	CM_SAMPLER_8X8_DESCR		samplerStateDescr;
	CM_AVS_STATE_MSG			AvsStateMsg;
	CM_AVS_NONPIPLINED_STATE	AvsState;
	SamplerIndex*				sampler_indx;
	sampler8x8_surface_info_t	sampler8x8_surface;		// the surface which the sampler will sample
	uint						kernel_arg_indx;		// the index in the kernel arguments list

} sampler8x8_info_t;

typedef struct
{
	CmBuffer*					handle;
	void *						pSysMemSrc;
	SurfaceIndex*				surf_indx;
	uint						kernel_arg_indx;
	const char*					file_path;
	void*						host_buff;
	uint						offset;
	uint						size;
	buffer_direction_t			direction;
	buffers_flag_t				flags;
	element_size_t				element_size;		// size each element in the buffers

} buffers_info_t;

typedef struct
{
	void*						pData;					//	pointer to the data
	uint						size;					//	the size of the data [bytes]
	uint						kernel_arg_indx;		//	the index in the kernel arguments list
	bool						keep_memory;			/*< unfree the memory in the end, 
															useful when we use vectors as CURBE >*/
													
} curbe_data_t;

// all the arguments that are needed in order to invoke the kernel
typedef struct
{
	CmKernel*					kernel;										// instance of a kernel in the program
	const char*					kernel_name;								// the main entry of the kernel
	CmEvent*					kernel_event;
	uint						threadswidth;
	uint						threadsheight;
	CmThreadSpace*				pTS;
	
	// CURBE data
	curbe_data_t				curbe_args[MAX_KERNEL_CURBE_ARGUMENTS];		// curbe data for the kernel
	uint						num_curbe_data;
	
	// 2D media surfaces
	media_surface_info_t		media_surface[MAX_KERNEL_MEDIA_SURFACES];	// 2D surfaces of the kernel	
	uint						num_media_surface_info;						// the number of 2D surface	

	// 1D buffers
	buffers_info_t				kernel_buffers[MAX_KERNEL_BUFFERS];			// 1D buffers of the kernel
	uint						num_kernel_buffers;							// the number of 1D buffers

	// samplers
	sampler_info_t				samplers_args[MAX_KERNEL_SAMPLERS_ARGUMENTS];	
	uint						num_samplers_args;

	// samplers 8x8
	sampler8x8_info_t			samplers8x8_args[MAX_KERNEL_SAMPLERS_ARGUMENTS];
	uint						num_samplers8x8_args;

} kernel_args_t;



/*
 *  load a program from a given path.
 *	
 *	Return:
 *		 the length of the program.
 */
static uint load_program_from_file( const char *filename, void* & pCommonISACode )
{
    struct stat		statbuf;
    FILE*			fh;
    BYTE*			source = NULL;
	errno_t			err;

	assert( filename );

	err = fopen_s( &fh, filename, "rb" );
    if ( err )
        throw Exception( "Error while opening program file: " + std::string(filename) );

    stat( filename, & statbuf );
    source = (BYTE*) malloc( statbuf.st_size + 1 );	// allocate memory for the binary file
	if ( ! source )
		throw Exception( "Error while allocating memory for program source");
	int read = fread(source, 1, statbuf.st_size, fh);
    if ( read != (unsigned int)statbuf.st_size )
    	 throw Exception( "Error while reading program from file: " + std::string(filename) );

	fclose( fh );

    source[statbuf.st_size] = '\0';					// mark the end with terminal char 

	pCommonISACode = source;

    return statbuf.st_size;
}

/*
 *  work around when using BMP files. The image should be fliped both in the vertical and horizontal
 *	directions before the buffer being sent to the kernel and fliped again before writing to file.
 */
static void inverse_buffer( unsigned char* src, unsigned int size, ushort width, ushort height )
{
	unsigned char* buff = (unsigned char*)malloc( size );
	if( ! buff )
		throw Exception( "Error: Failed to allocated buffer!" );

	assert( size % 4 == 0 );

	// mirroring top - bottom 
	unsigned char* surf_buff = (unsigned char*)src;
	for ( unsigned int i = 0; i < size; i += 4 )
	{
		buff[ size - i - 1 - 3] = surf_buff[i];
		buff[ size - i - 1 - 2] = surf_buff[i + 1];
		buff[ size - i - 1 - 1] = surf_buff[i + 2];
		buff[ size - i - 1] = surf_buff[i + 3];
	}
	memcpy( surf_buff, buff, size );

	// mirroring left - right
	uint pos = width * 4;
	for ( unsigned int i = 0; i < size; i += 4 )
	{
		if( i % (width * 4) == 0 )
			pos = i + (width * 4);
	

		pos -= 4;
		assert( pos + 3 < size );

		buff[pos] = surf_buff[i];
		buff[pos + 1] = surf_buff[i + 1];
		buff[pos + 2] = surf_buff[i + 2];
		buff[pos + 3] = surf_buff[i + 3];
	}
	memcpy( surf_buff, buff, size );

	free(buff);
	buff = NULL;
}

static void inverse_buffer( unsigned short* src, unsigned int size, ushort width, ushort height )
{
	unsigned short* buff = (unsigned short*)malloc( size );
	if( ! buff )
		throw Exception( "Error: Failed to allocated buffer!" );

	assert( size % 8 == 0 );

	// mirroring top - bottom 
	unsigned short* surf_buff = src;
	for ( unsigned int i = 0; i < size >> 1; i += 4 )
	{
		buff[ size - i - 1 - 3] = surf_buff[i];
		buff[ size - i - 1 - 2] = surf_buff[i + 1];
		buff[ size - i - 1 - 1] = surf_buff[i + 2];
		buff[ size - i - 1] = surf_buff[i + 3];
	}
	memcpy( surf_buff, buff, size );

	// mirroring left - right
	uint pos = width * 4;
	for ( unsigned int i = 0; i < size >> 1; i += 4 )
	{
		if( i % (width * 4) == 0 )
			pos = i + (width * 4);
	

		pos -= 4;
		assert( pos + 3 < size >> 1 );

		buff[pos] = surf_buff[i];
		buff[pos + 1] = surf_buff[i + 1];
		buff[pos + 2] = surf_buff[i + 2];
		buff[pos + 3] = surf_buff[i + 3];
	}
	memcpy( surf_buff, buff, size );

	free(buff);
	buff = NULL;
}

/*
 *  fill the destination buffer "dst" with the data that contain in file "file_path" or in 
 *	another host buffer "src_buffer" (in case file_path is set the data would be loaded from
 *	the file otherwise src_buffer must be set)
 *	
 *	dst:			Destination buffer
 *	file_path:		A path to a file that it's contant should be loaded
 *	offset:			Offset from the begining of the given file to start read [bytes]
 *	src_buff:		Another way to fill the buffer, in case the file path "file_path" is unset
 *					this buffer would be used as a source.
 *	size:			Size of the destination buffer "dst"
 *	flags:			Bit flag that indicaes the way the data should be loaded.
 *	
 *	Return:
 *		 
 */
static void load_data_to_buffer( void*			dst, 
								 const char*	file_path,
								 uint			offset,
								 void*			src_buff,
								 uint			size,
								 uint			flags,
								 element_size_t	element_size )
{
	assert( dst );
	assert( size );

	if ( file_path )
	{		
		FILE* in = NULL;
		errno_t err = fopen_s( &in, file_path, "rb" );
		if ( err )
			throw Exception( "Error opening input files" );

		// calculate the size of the file
		struct stat statbuf;
		stat( file_path, & statbuf );

		if ( offset )
			fseek ( in , offset , SEEK_SET );

		unsigned long to_read = MIN( statbuf.st_size - offset, size );

		if( flags & RGB_2_RGBA )
		{
			if ( ELEMENT_SIZE_BYTE == element_size )
			{
				unsigned char* buff = (unsigned char*)malloc( to_read );
				if( ! buff )
					throw Exception( "Error: Failed to allocated buffer!" );

				if( fread( buff, 1, to_read, in) != to_read )
					throw Exception( "Error: Failed to read input file" + std::string(file_path) );

				unsigned int j = 0;
				unsigned char* surf_buff = (unsigned char*)dst;
				for ( unsigned int i = 0; i < size; i += 4 )
				{
					surf_buff[ i ] = buff[ j++ ];
					surf_buff[ i + 1 ] = buff[ j++ ];
					surf_buff[ i + 2 ] = buff[ j++ ];
					surf_buff[ i + 3 ] = 0;							// add alpha component
				}

				free(buff);
				buff = NULL;
			}
			else if ( ELEMENT_SIZE_WORD == element_size )
			{
				unsigned short* buff = (unsigned short*)malloc( to_read );
				if( ! buff )
					throw Exception( "Error: Failed to allocated buffer!" );

				if( fread( buff, 1, to_read, in) != to_read )
					throw Exception( "Error: Failed to read input file" + std::string(file_path) );

				unsigned int j = 0;
				unsigned short* surf_buff = (unsigned short*)dst;
				for ( unsigned int i = 0; i < size >> 1; i += 4 )
				{
					surf_buff[ i ] = buff[ j++ ];
					surf_buff[ i + 1 ] = buff[ j++ ];
					surf_buff[ i + 2 ] = buff[ j++ ];
					surf_buff[ i + 3 ] = 0;							// add alpha component
				}

				free(buff);
				buff = NULL;
			}
			else
			{
				throw Exception( "Error: unsupported element size..." );
			}
		}
		else
		{
			if( fread( dst, 1, to_read, in) != to_read )
				throw Exception( "Error: Failed to read input file" + std::string(file_path) );
		}

		fclose(in);
	}
	else if( src_buff )
	{
		memcpy( dst, src_buff, size );
	}
	else
	{
		throw Exception( "Error: input surface with no data was supplied" );
	}
}


// create a new device and load a program to the context
void create_device_context( device_context_t & device_context )
{
	UINT version = 0;
	int result;

	result = ::CreateCmDevice( device_context.pCmDev, version );
	if (result != CM_SUCCESS ) 
		throw Exception( "CmDevice creation error" );
	
	if( version < CM_1_0 )
		throw Exception( "The runtime API version is later than runtime DLL version" );

	// Create a task queue
	result = device_context.pCmDev->CreateQueue( device_context.pCmQueue );
	if (result != CM_SUCCESS ) 
		throw Exception( "CM CreateQueue error"  );

	result = device_context.pCmDev->CreateTask( device_context.pKernelArray );
	if (result != CM_SUCCESS ) 
		throw Exception( "CmDevice CreateTask error" );

	// load the program into a buffer	
	if ( ! device_context.program_path )
		throw Exception( "Error: A path to program file wasn't specified!" );

	uint code_size = load_program_from_file( device_context.program_path, device_context.pCommonISACode );

	assert( code_size );
	assert( device_context.pCommonISACode );
	
	// attach the program code to the device 
	result = device_context.pCmDev->LoadProgram( device_context.pCommonISACode, 
												 code_size, 
												 device_context.program ); 
	if (result != CM_SUCCESS ) 
		throw Exception( "CM LoadProgram error" );
}

// create a kernel instance from the loaded program 
void create_kernel( device_context_t & device_context, kernel_args_t & kernel_args )
{
	int result; 

	assert( device_context.program );
	
	// TODO: uncomment when the CM team fix CM_KERNEL_FUNCTION2
	/*
	// Create a kernel	
	if ( ! kernel_args.kernel_name )
		throw Exception("Error: Kernel name wasn't specified!");
	result = device_context.pCmDev->CreateKernel( device_context.program, 
												  CM_KERNEL_FUNCTION(kernel_args.kernel_name), 
												  kernel_args.kernel ); 
	if (result != CM_SUCCESS ) 
		throw Exception( "CM CreateKernel error"  );
	*/

	// create thread space
	assert( kernel_args.threadswidth && kernel_args.threadsheight );
	kernel_args.kernel->SetThreadCount( kernel_args.threadswidth * kernel_args.threadsheight );
	result = device_context.pCmDev->CreateThreadSpace( kernel_args.threadswidth, 
													   kernel_args.threadsheight, 
													   kernel_args.pTS );
	if (result != CM_SUCCESS ) 
		throw Exception( "CM CreateThreadSpace error"  );
		
	result = device_context.pKernelArray-> AddKernel ( kernel_args.kernel );
	if (result != CM_SUCCESS ) 
		throw Exception( "CmDevice AddKernel error"  );
}

// allocate the 2D surfaces for the kernel
void alloc_media_surfaces( device_context_t & device_context, kernel_args_t & kernel_args )
{
	int result;
	UINT pitch_Surf;
	UINT size_Surf;

	for ( uint i = 0; i < kernel_args.num_media_surface_info; ++i )
	{
		media_surface_info_t* tmp = & kernel_args.media_surface[i];

		assert( tmp->width && tmp->height );

		pitch_Surf = 0;
		size_Surf = 0;
		
		// get information regarding the size of the buffer
		device_context.pCmDev->GetSurface2DInfo( tmp->width, 
												 tmp->height, 
												 tmp->surface_type, 
												 pitch_Surf, 
												 size_Surf);

		// allocate the buffer
		tmp->pSysMemSrc = malloc(size_Surf);
		if ( ! tmp->pSysMemSrc )
			throw Exception( "Error while allocating buffer for surface" );

		// init the buffer
		memset( tmp->pSysMemSrc, 0, tmp->size );
		/*
		result = device_context.pCmDev->CreateSurface2DUP( tmp->width, 
											   			   tmp->height, 
														   tmp->surface_type, 
														   tmp->pSysMemSrc, 
														   tmp->handle );
		*/
		result = device_context.pCmDev->CreateSurface2D( tmp->width, 
													     tmp->height, 
														 tmp->surface_type, 
														 tmp->handle );
		if ( result != CM_SUCCESS ) 
			throw Exception( "CM CreateSurface2DUP error" );


		
		tmp->handle->GetIndex( tmp->surf_indx );
		kernel_args.kernel->SetKernelArg( tmp->kernel_arg_indx, sizeof(SurfaceIndex),tmp->surf_indx ); 
	}
}


// alocatethe 1D buffers for the kernel
void alloc_bueffrs( device_context_t & device_context, kernel_args_t & kernel_args )
{
	int result;

	for ( uint i = 0; i < kernel_args.num_kernel_buffers; ++i )
	{
		buffers_info_t* tmp = & kernel_args.kernel_buffers[i];

		// allocate the buffer
		tmp->pSysMemSrc = CM_ALIGNED_MALLOC( tmp->size, sizeof(float) );

		result = device_context.pCmDev->CreateBuffer(tmp->size, tmp->handle);
		if ( result != CM_SUCCESS ) 
			throw Exception( "CM CreateBufferUP error" );

		// init the buffer
		memset( tmp->pSysMemSrc, 0, tmp->size );

		tmp->handle->GetIndex( tmp->surf_indx );

		kernel_args.kernel->SetKernelArg( tmp->kernel_arg_indx, sizeof(SurfaceIndex), tmp->surf_indx ); 
	
	}
}

// set the curbe data for the given kernel
void set_kernel_curbe_data( kernel_args_t & kernel_args )
{
	for ( uint i = 0; i < kernel_args.num_curbe_data; ++i )
	{
		curbe_data_t* tmp = & kernel_args.curbe_args[i];
		assert( tmp->pData );
		kernel_args.kernel->SetKernelArg( tmp->kernel_arg_indx, tmp->size, tmp->pData ); 
	}
}

// initialize the context of the samplers that are used by the kernel
void init_kernel_samplers( device_context_t & device_context, kernel_args_t & kernel_args )
{
	int result;  
	
	for ( uint i = 0; i < kernel_args.num_samplers_args; ++i )
	{
		sampler_info_t* tmp = & kernel_args.samplers_args[i];

		result = device_context.pCmDev->CreateSampler ( tmp->sampleState, tmp->pSampler );
		if ( result != CM_SUCCESS ) 
			throw Exception( "CM CreateSampler error" );
	
		tmp->pSampler->GetIndex(tmp->sampler_indx );
		kernel_args.kernel->SetKernelArg( tmp->kernel_arg_indx, sizeof(SamplerIndex), tmp->sampler_indx );
		std::cout<< "\tinit_kernel_samplers done id = \t = "<< tmp->kernel_arg_indx << std::endl;
	}
}

// initialize the context of the 8x8 samplers that are beeing used by the kernel
void init_kernel_samplers8x8( device_context_t & device_context, kernel_args_t & kernel_args )
{
	int result;

	for ( uint i = 0; i < kernel_args.num_samplers8x8_args; ++i )
	{
		sampler8x8_info_t* tmp = & kernel_args.samplers8x8_args[i];

		tmp->samplerStateDescr.avs = &(tmp->AvsStateMsg);
		tmp->samplerStateDescr.avs->AvsState = & (tmp->AvsState);

		// Create sampler state using sampler state descriptor 
		result = device_context.pCmDev->CreateSampler8x8( tmp->samplerStateDescr, tmp->pSampler8x8);
		if (result != CM_SUCCESS ) 
			throw Exception( "CM CreateSampler8x8 error." );

		tmp->pSampler8x8->GetIndex( tmp->sampler_indx );
		kernel_args.kernel->SetKernelArg( tmp->kernel_arg_indx, sizeof(SamplerIndex), tmp->sampler_indx );
	

		// Create a 2D surface for input
		// Open input file

		sampler8x8_surface_info_t* surf_tmp = & tmp->sampler8x8_surface;

		unsigned char* buff = (unsigned char*)malloc( surf_tmp->size );
		if ( ! buff )
			throw Exception( "Error during allocation buffer for sampler 8x8 input surface" );

		load_data_to_buffer( buff, 
							 surf_tmp->file_path, 
							 surf_tmp->offset, 
							 surf_tmp->host_buff,
							 surf_tmp->size,
							 surf_tmp->flags,
							 surf_tmp->element_size );

		// workaround when using BMP
		if ( surf_tmp->flags & INVERSE )
			inverse_buffer( buff, surf_tmp->size, surf_tmp->width, surf_tmp->height );

		result = device_context.pCmDev->CreateSurface2D( surf_tmp->width, 
													     surf_tmp->height, 
														 surf_tmp->surface_type, 
														 surf_tmp->handle );
		if (result != CM_SUCCESS ) 
			throw Exception( "CM CreateSurface2D error for sampler8x8 input surface" );

		// Init input surface with input image
		result = surf_tmp->handle->WriteSurface( buff, NULL );
		if (result != CM_SUCCESS ) 
			throw Exception("CM WriteSurface error");

		free( buff );
		buff = NULL;
        
		result = device_context.pCmDev->CreateSampler8x8Surface( surf_tmp->handle,
																 surf_tmp->surf_indx,
																 CM_AVS_SURFACE );

		if (result != CM_SUCCESS ) 
			throw Exception( "CM Sampler8x8Surface error" );
		
		kernel_args.kernel->SetKernelArg( surf_tmp->kernel_arg_indx, 
										  sizeof(SurfaceIndex),
										  surf_tmp->surf_indx ); 

	}
}

// write the data that find in the host buffer to the CM 2D surfaces
void write_data_to_2D_surface( kernel_args_t & kernel_args )
{
	// write the data to the input surfaces
	for ( uint i = 0; i < kernel_args.num_media_surface_info; ++i )
	{
		media_surface_info_t* tmp = & kernel_args.media_surface[i];

		if ( BUFFER_DIRECTION_INPUT != tmp->direction )
		{
			continue; // nothing to copy
		}

		load_data_to_buffer( tmp->pSysMemSrc, 
							 tmp->file_path, 
							 tmp->offset, 
							 tmp->host_buff,
							 tmp->size,
							 tmp->flags,
							 tmp->element_size );
		
		// Init input surface with input image
		int result = tmp->handle->WriteSurface((const unsigned char*)tmp->pSysMemSrc, NULL);
		if (result != CM_SUCCESS ) 
			throw Exception("CM WriteSurface error");
			

	}
}

// write the data that find in the host buffer to the CM 1D buffer
void write_data_to_1D_buffer( kernel_args_t & kernel_args )
{
	for ( uint i = 0; i < kernel_args.num_kernel_buffers; ++i )
	{
		buffers_info_t* tmp = & kernel_args.kernel_buffers[i];
		
		if ( BUFFER_DIRECTION_INPUT != tmp->direction )
		{
			continue; // nothing to copy
		}
		
		load_data_to_buffer( tmp->pSysMemSrc, 
							 tmp->file_path, 
							 tmp->offset, 
							 tmp->host_buff,
							 tmp->size,
							 tmp->flags,
							 tmp->element_size );

			// Init input surface with input image
		int result = tmp->handle->WriteSurface((const unsigned char *)tmp->pSysMemSrc, NULL );
		if (result != CM_SUCCESS ) 
			throw Exception("CM WriteSurface buffer error");

	}

}

// perform the actual calculation of the kernel
void start_kernel_task(	device_context_t & device_context, kernel_args_t & kernel_args )
{
	int result = 0;
	
	assert( kernel_args.kernel_name );
	assert( device_context.pCmQueue );
#ifndef CMRT_EMU
	printf("Using grits path: ");
	system("echo GRITS_PATH: %GRITS_PATH%");
#endif
	
	std::cout<< "Running the kernel: "<< kernel_args.kernel_name << std::endl;
	result = device_context.pCmQueue->Enqueue( device_context.pKernelArray, 
											   kernel_args.kernel_event, 
											   kernel_args.pTS);
	if (result != CM_SUCCESS ) 
		throw Exception( "CmDevice enqueue error" );

}

// read the result of the kernel and dump it to a file
void retrieve_result( device_context_t & device_context, kernel_args_t & kernel_args ) 
{
	int result;

	//Wait on enqueue event to ensure kernel finished processing (mostly for HW mode)
	CM_STATUS status;
	do 
	{
		result = kernel_args.kernel_event->GetStatus(status);
		if (result != CM_SUCCESS ) 
			throw Exception( "Failed polling CM event" );
			
		Sleep(1);
	} while(status != CM_STATUS_FINISHED);

	std::cout<< "\nKernel " << kernel_args.kernel_name <<" done...\n" << std::endl;
	
	// dump the output surfaces to files
	for ( uint i = 0; i < kernel_args.num_media_surface_info; ++i )
	{
		media_surface_info_t* tmp = & kernel_args.media_surface[i];

#ifndef DEBUG		
		if ( BUFFER_DIRECTION_OUTPUT != tmp->direction )
		{
			continue; // skip this surface
		}
#endif
		tmp->handle->ReadSurface((unsigned char*)tmp->pSysMemSrc, NULL);

	
		// workaround when using BMP 
		if( tmp->flags & INVERSE )
			inverse_buffer( (unsigned char*)tmp->pSysMemSrc, tmp->size, tmp->width, tmp->height );
		

		if ( tmp->file_path )
		{
			// if a file path was supplied we dump the buffer to it
			FILE* out = NULL;
			errno_t	err = fopen_s( &out, tmp->file_path, "ab" );

			if ( err )
				throw Exception( "Error opening output file" );

			if( tmp->flags & RGBA_2_RGB )
			{
				unsigned char* buff_out = NULL;

				if ( ELEMENT_SIZE_BYTE == tmp->element_size )
				{
					unsigned char* buff = (unsigned char*)malloc( tmp->size );
					if( ! buff )
						throw Exception( "Error: Failed to allocated buffer!" );

					unsigned int j = 0;
					unsigned char* surf_buff = (unsigned char*)tmp->pSysMemSrc;
					for ( unsigned int i = 0; i < tmp->size; i += 4 )
					{
						buff[ j++ ] = surf_buff[ i ];
						buff[ j++ ] = surf_buff[ i + 1];
						buff[ j++ ] = surf_buff[ i + 2];
						// ignore alpha component
					}

					buff_out = buff;
				}
				
				else if ( ELEMENT_SIZE_WORD == tmp->element_size )
				{
					unsigned short* buff = (unsigned short*)malloc( tmp->size );
					if( ! buff )
						throw Exception( "Error: Failed to allocated buffer!" );

					unsigned int j = 0;
					unsigned short* surf_buff = (unsigned short*)tmp->pSysMemSrc;
					for ( unsigned int i = 0; i < tmp->size >> 1; i += 4 )
					{
						buff[ j++ ] = surf_buff[ i ];
						buff[ j++ ] = surf_buff[ i + 1];
						buff[ j++ ] = surf_buff[ i + 2];
						// ignore alpha component
					}

					buff_out = (unsigned char*)buff;
				}
				else
				{
					throw Exception( "Error: unsupported element size..." );
				}
		
				if ( fwrite(buff_out, 1, (tmp->size * 3) / 4 , out) !=  (tmp->size * 3) / 4 ) 
					throw Exception( "Error writing to output file" );

				free( buff_out );
				buff_out = NULL;
			}
			else
			{
				if ( fwrite(tmp->pSysMemSrc, 1, tmp->size, out) !=  tmp->size ) 
					throw Exception( "Error writing to output file" );
			}

			fclose ( out );
		}
	}

	for ( uint i = 0; i < kernel_args.num_kernel_buffers; ++i )
	{
		buffers_info_t* tmp = & kernel_args.kernel_buffers[i];

		if ( BUFFER_DIRECTION_OUTPUT != tmp->direction )
		{
			continue; // skip this buffer
}

		if ( tmp->file_path )
		{
			FILE* out = NULL;
			errno_t	err = fopen_s( &out, tmp->file_path, "wb" );
			if ( err )
				throw Exception( "Error opening output file" );
			if ( tmp->offset )
				fseek ( out , tmp->offset , SEEK_SET );
			if( tmp->flags & RGBA_2_RGB )
			{
				unsigned char* buff_out = NULL;
				if ( ELEMENT_SIZE_BYTE == tmp->element_size )
				{
					unsigned char* buff = (unsigned char*)malloc( tmp->size );
					if( ! buff )
						throw Exception( "Error: Failed to allocated buffer!" );
					unsigned int j = 0;
					unsigned char* surf_buff = (unsigned char*)tmp->pSysMemSrc;
					for ( unsigned int i = 0; i < tmp->size; i += 4 )
					{
						buff[ j++ ] = surf_buff[ i ];
						buff[ j++ ] = surf_buff[ i + 1];
						buff[ j++ ] = surf_buff[ i + 2];
					}
					buff_out = buff;
				}
				else if ( ELEMENT_SIZE_WORD == tmp->element_size )
				{
					unsigned short* buff = (unsigned short*)malloc( tmp->size );
					if( ! buff )
						throw Exception( "Error: Failed to allocated buffer!" );
					unsigned int j = 0;
					unsigned short* surf_buff = (unsigned short*)tmp->pSysMemSrc;
					for ( unsigned int i = 0; i < tmp->size >> 1; i += 4 )
					{
						buff[ j++ ] = surf_buff[ i ];
						buff[ j++ ] = surf_buff[ i + 1];
						buff[ j++ ] = surf_buff[ i + 2];
					}
					buff_out = (unsigned char*)buff;
				}
				if ( fwrite(buff_out, 1, (tmp->size * 3) / 4 , out) !=  (tmp->size * 3) / 4 ) 
					throw Exception( "Error writing to output file" );
				free( buff_out );
				buff_out = NULL;
			}
			else
			{
				if ( fwrite(tmp->pSysMemSrc, 1, tmp->size, out) !=  tmp->size ) 
					throw Exception( "Error writing to output file" );
			}
			fclose ( out );
		}
	}
}

// release all the resources that were allocated for the media surfaces 
void release_media_surfaces_resources( CmDevice* pCmDev,
									   media_surface_info_t* media_surface, 
									   uint num_media_surface_info )
{
	for ( uint i = 0; i < num_media_surface_info; ++i )
	{
		media_surface_info_t* tmp = & media_surface[i];

		/*if ( tmp->handle )
			pCmDev->DestroySurface2D( tmp->handle );*/

	//	if ( tmp->pSysMemSrc )
	//		free( tmp->pSysMemSrc );

		if ( tmp->host_buff )
			free( tmp->host_buff );
	}
}

// release all the resources that were allocated for 1D buffers
void release_kernel_buffers( CmDevice* pCmDev,
							 buffers_info_t* buffers, 
							 uint num_kernel_buffers )
{
	for ( uint i = 0; i < num_kernel_buffers; ++i )
	{
		buffers_info_t* tmp = & buffers[i];

		//if ( tmp->handle )
		//	pCmDev->DestroyBufferUP( tmp->handle );

	//	if ( tmp->pSysMemSrc )
	//		free( tmp->pSysMemSrc );

		if ( tmp->host_buff )
			free( tmp->host_buff );
	}
}

// release all the resources that were allocated for the samplers of the kernel
void deinit_kernel_samplers( CmDevice* pCmDev, sampler_info_t* samplers_args, uint num_samplers )
{
	for ( uint i = 0; i < num_samplers; ++i )
	{
		sampler_info_t* tmp = & samplers_args[i];
		
		// FIXME: handle the exception
//		if ( tmp->pSampler  )	
//			pCmDev->DestroySampler ( tmp->pSampler );		
	}
}

// release all the resources that were allocated for the 8x8 samplers of the kernel
void deinit_kernel_samplers8x8( CmDevice* pCmDev, sampler8x8_info_t* samplers8x8_args, uint num_samplers8x8 )
{
	for ( uint i = 0; i < num_samplers8x8; ++i )
	{
		sampler8x8_info_t* tmp = & samplers8x8_args[i];
		
		// FIXME: handle the exception
//		if ( tmp->pSampler  )	
//			pCmDev->DestroySampler ( tmp->pSampler );	

		assert( tmp->sampler8x8_surface.surf_indx );
		pCmDev->DestroySampler8x8Surface( tmp->sampler8x8_surface.surf_indx );

		assert( tmp->sampler8x8_surface.handle );
		pCmDev->DestroySurface( tmp->sampler8x8_surface.handle );

		if ( tmp->sampler8x8_surface.host_buff )
			free(tmp->sampler8x8_surface.host_buff);
	}
}

// release all the resources that were allocated for the given kernel
void release_kernel_resources( device_context_t & device_context, kernel_args_t & kernel_args )
{
	// release all the 2D surfaces that were allocated
	release_media_surfaces_resources( device_context.pCmDev, 
									  kernel_args.media_surface, 
									  kernel_args.num_media_surface_info );

	// release all the 1D buffers that were allocated
	release_kernel_buffers( device_context.pCmDev, 
							kernel_args.kernel_buffers,
							kernel_args.num_kernel_buffers );

	// release all the samplers that were used by this kernel
	deinit_kernel_samplers( device_context.pCmDev, 
							kernel_args.samplers_args, 
							kernel_args.num_samplers_args );

	// release all the samplers that were used by this kernel
	deinit_kernel_samplers8x8( device_context.pCmDev, 
							   kernel_args.samplers8x8_args, 
							   kernel_args.num_samplers8x8_args );

	for ( uint i = 0; i < kernel_args.num_curbe_data; ++i )
	{
		curbe_data_t* tmp = & kernel_args.curbe_args[i];
		
		if ( ! tmp->keep_memory )	// check whether the user asked to free the memory or not
		{
			assert( tmp->pData );
			free( tmp->pData );
		}
	}

	if ( kernel_args.pTS )
		device_context.pCmDev->DestroyThreadSpace( kernel_args.pTS );

	if ( kernel_args.kernel )
		device_context.pCmDev->DestroyKernel( kernel_args.kernel );

	// ensure we won't make double free
	memset( & kernel_args, 0, sizeof( kernel_args ) );
}

/*
 * release all the resources that were created for the device - should be called once all the 
 * kernels' resources were released
 */
void release_device_resources( device_context_t & device_context )
{
	if ( device_context.pKernelArray )
		device_context.pCmDev->DestroyTask( device_context.pKernelArray );

	if ( device_context.pCmDev )
		::DestroyCmDevice( device_context.pCmDev );  
	
	if ( device_context.pCommonISACode )
		free( device_context.pCommonISACode );

	// ensure we won't make double free
	memset( & device_context, 0, sizeof( device_context ) );
}


#endif //  __HOST_H_