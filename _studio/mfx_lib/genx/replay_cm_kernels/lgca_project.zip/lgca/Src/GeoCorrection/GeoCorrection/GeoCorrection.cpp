/*===================== begin_copyright_notice ==================================

INTEL CONFIDENTIAL
Copyright 2012-2014
Intel Corporation All Rights Reserved.

The source code contained or described herein and all documents related to the
source code ("Material") are owned by Intel Corporation or its suppliers or
licensors. Title to the Material remains with Intel Corporation or its suppliers
and licensors. The Material contains trade secrets and proprietary and confidential
information of Intel or its suppliers and licensors. The Material is protected by
worldwide copyright and trade secret laws and treaty provisions. No part of the
Material may be used, copied, reproduced, modified, published, uploaded, posted,
transmitted, distributed, or disclosed in any way without Intel�s prior express
written permission.

No license under any patent, copyright, trade secret or other intellectual
property right is granted to or conferred upon you by disclosure or delivery
of the Materials, either expressly, by implication, inducement, estoppel or
otherwise. Any license under such intellectual property rights must be express
and approved by Intel in writing.

======================= end_copyright_notice ==================================*/

// Comment to remove debug instructions - should be comment in the kernel too
//#define DEBUG

// camera_pipe.cpp  : Defines the entry point for the console application.
//

#include <iostream>

#include "host.h"
#include "config_parser.h"

#define ISA_FILE_NAME							"GeoCorrection_genx.isa"
#define GENX_KERNEL_POINT						camera_pipe

// description of the argument list of the kernel
#define	USAGE_DESCRIPTION						(" <src file> <dst> <AVS block size: 16x4|8x4|4x4> <pixel precision: 8|16> [coefficients file]	\
\n\n\tsrc file: path to BMP file with 24 bits color depth | raw data of 16 bits of RGB values. \
\n\n\tin case of 16 bits input, MUST add resolution in the following manner						\
\n\n\t\t--width <width in pixels> --height <height in pixels>\n")

// number of expected arguments from the comman line
#define NUM_ARGUMENTS							(6)		

#define BLOCK_SIZE_WIDTH						(16.0f)
#define BLOCK_SIZE_HEIGHT						(16.0f)

#define AVS_BLOCK_SIZE_16x4						(1<<0)
#define AVS_BLOCK_SIZE_8x4						(1<<1)
#define AVS_BLOCK_SIZE_4x4						(1<<2)

#define PIXEL_PRECISION_16_BITS					(1<<0)
#define PIXEL_PRECISION_8_BITS					(1<<1)

#define TEST_VAL_NORM_CENTER_Y                (0.5f)
#define TEST_VAL_NORM_CENTER_X                (0.5f)

// Other defines
#define ARGUMENT_INPUT_PATH						(1)
#define ARGUMENT_OUTPUT_PATH					(2)
#define ARGUMENT_BLOCK_SIZE						(3)
#define ARGUMENT_BIT_PRECISION					(4)
#define ARGUMENT_COEFFICIENTS_PATH				(5)
#define PIC_HEADER_LENGTH						(54)

#ifdef CMRT_EMU


extern "C" void camera_pipe(		SamplerIndex		sampler_config, 
	SurfaceIndex		src_surf,					
	SurfaceIndex		dst_surf, 
	SurfaceIndex		sample_params,
	SurfaceIndex		sample_statistics,
	ushort				height,
	ushort				width,
	ushort				correction_type,
	uchar				block_size,
	uchar				pixel_precision,
	ushort				alpha_overwrite,
	ushort				alpha_value,
	ushort				scaling_enable,

	float				norm_dist_center_X, // R1.5					- offset 52
	float				norm_dist_center_Y

	);
#endif

typedef struct 
{
	float x0;
	float dx;
	float ddx;

	float y0;
	float dy;
	float ddy;

} TAvsMsg;

typedef struct 
{
	int max_x0_y0[8];
	int min_x0_y0[8];

} StatisticsMsg;

// the index of the first kernel arguments that related to debug
static uint	first_kernel_args_debug	= 0;	


// =====================>
//	Global variables
// =====================>

// indicate if our input surface is a BMP file or not
static unsigned char header[PIC_HEADER_LENGTH];

// the resolution of the input when using 16 bits input
static unsigned short	m_width_16bit	= 0;
static unsigned short	m_height_16bit	= 0;

// block sizes
static unsigned int m_Hor_Block_Size = 0xffff;
static unsigned int m_Ver_Block_Size = 0xffff; 
static unsigned int block_size_flag = 0xffff;  
static unsigned int pixel_precision_flag = 0xffff;


// default values for the lens correction

const static double m_a = -0.050000000000000f; 
const static double m_b = 0.001800000000000f; 
const static double m_c = 0.000000000000000f; 
//const static double m_d = 1.048200000000000f; 

/*
//Sony camera values
const static double m_c = 0.005000000000000f; //1rd deg
const static double m_b = 0.120000000000000f; //2nd deg
const static double m_a = -0.080000000000000f; //3rd deg
const static double m_d = 0.955000000000000f; 
*/
static unsigned char    ctrl_mode = 1;
static unsigned char	glc_mode = 0;
static unsigned char	ca_mode	= 1;
unsigned short overwr_alpha = 0;
unsigned short alpha_value = 0;
unsigned short scaling_enable = 0;


vector<float, 3>  r_coeff;
vector<float, 3>  g_coeff;
vector<float, 3>  b_coeff;

static unsigned int threadswidth = 0;
static unsigned int threadsheight = 0;

// forward declaration 
void prepare_kernel_args( kernel_args_t & kernel_args  );
void parse_arguments( int argc, char * argv[], kernel_args_t & kernel_args );

// ======================================================================================>
//
//				This part should be completed by you
//
// ======================================================================================>



// parse the given arguments and print a usage message in case of error
void parse_arguments( int argc, char * argv[], kernel_args_t & kernel_args )
{
	if ( argc < NUM_ARGUMENTS + 1 /* include the program name */ )
	{
		std::cerr << "\n   Usage: " << argv[0] << USAGE_DESCRIPTION << std::endl;
		std::cerr<< "\n\nPress Enter key to continue..." << std::endl;
		getchar();	// wait for input from user so he will be able to read the error message
		exit( EXIT_FAILURE );
	}

	// input file - this surface should be for sampler8x8
	kernel_args.samplers8x8_args[0].sampler8x8_surface.file_path = argv[1];

	// output 
	kernel_args.media_surface[0].direction = BUFFER_DIRECTION_OUTPUT;
	kernel_args.media_surface[0].file_path = argv[2];

	// determine AVS macro block size //ARGUMENT_BLOCK_SIZE=3
	if ( ! strcmp( argv[3], "16x4" ) )
	{
		block_size_flag = AVS_BLOCK_SIZE_16x4;
		m_Hor_Block_Size = 16;
		m_Ver_Block_Size = 4;
	}
	else if ( ! strcmp( argv[3], "8x4" ) )
	{
		block_size_flag = AVS_BLOCK_SIZE_8x4;
		m_Hor_Block_Size = 8;
		m_Ver_Block_Size = 4;
	}
	else if ( ! strcmp( argv[3], "4x4" ) )
	{
		block_size_flag = AVS_BLOCK_SIZE_4x4;
		// in case of 4x4 we need to program the number of threads like it was 8x4
		m_Hor_Block_Size = 4;	
		m_Ver_Block_Size = 4;
	}
	else
	{
		std::cerr << "Unknown AVS macro block size was given!\n" << std::endl;
		std::cerr << "\n   Usage: " << argv[0] << USAGE_DESCRIPTION << std::endl;
		std::cerr<< "\n\nPress Enter key to continue..." << std::endl;
		getchar();	// wait for input from user so he will be able to read the error message
		exit( EXIT_FAILURE );
	}

	// determine pixel precision


	if ( ! strcmp( argv[4], "8" ) )
	{
		pixel_precision_flag = PIXEL_PRECISION_8_BITS;
	}
	else if  ( ! strcmp( argv[4], "16" ) )
	{
		pixel_precision_flag = PIXEL_PRECISION_16_BITS;

		bool found_width = false, found_height = false;

		// get the input resolution 
		for ( uint i = 1; i < (uint)argc; ++i )
		{
			bool compress = false;

			if( ! strcmp( argv[i], "--width" ) )
			{
				m_width_16bit = atoi( argv[i+1] );

				found_width = true;
				compress = true;
			}

			if( ! strcmp( argv[i], "--height" ) )
			{
				m_height_16bit = atoi( argv[i+1] );
				found_height = true;
				compress = true;
			}

			if ( compress )
			{
				for ( uint j = i; j + 2 < (uint)argc; ++j )
				{
					argv[j] = argv[j + 2];
					argv[j+2] = "\0";
				}

				argc -= 2;
				--i;	// make sure we won't skip the next argument
			}
		}

		if ( ! found_width || ! found_height )
		{
			std::cerr << "\nError: Input resolution must be supplied for 16 bits input\n" << std::endl;
			std::cerr << "\t please add arguments --width <width in pixels> --height <height in pixels>\n" << std::endl;
			std::cerr<< "\n\nPress Enter key to continue..." << std::endl;
			getchar();	// wait for input from user so he will be able to read the error message
			exit( EXIT_FAILURE );
		}
	}
	else
	{
		std::cerr << "Unknown pixel precision was given!\n" << std::endl;
		std::cerr << "\n   Usage: " << argv[0] << USAGE_DESCRIPTION << std::endl;
		std::cerr<< "\n\nPress Enter key to continue..." << std::endl;
		getchar();	// wait for input from user so he will be able to read the error message
		exit( EXIT_FAILURE );
	}


	if ( ! strcmp( argv[5], "GLC" ) )
	{
		ctrl_mode = glc_mode;  //0
	}
	else if( ! strcmp( argv[5], "CA" ) )
	{
		ctrl_mode = ca_mode;  //1
	}

	if ( ! strcmp( argv[6], "1" ) )
	{
		overwr_alpha = 1;  //0
		alpha_value = atoi( argv[7] );
	}

	scaling_enable = atoi( argv[8] );


	std::cout<< "\nScaling enable: " << scaling_enable<< std::endl;

	std::cout << std::setprecision(10);
	std::cout << std::fixed;
	std::cout << std::endl << std::endl;


}

// prepare the arguments for the kernel
void prepare_kernel_args( kernel_args_t & kernel_args  )
{
	/*
	*	This function initialize the arguments for the kernel - including surfaces and curbe
	*	pay attention that the cure data doesn't include the surfaces (these are given during
	*	their creation).
	*/
	uint j;

	sampler8x8_surface_info_t* in_surf_args = & kernel_args.samplers8x8_args[0].sampler8x8_surface;

	const char* file_path = in_surf_args->file_path;
	assert( file_path );

	//	kernel_args.media_surface[1].direction = BUFFER_DIRECTION_INPUT;
	//	kernel_args.kernel_buffers[0].direction = BUFFER_DIRECTION_INPUT;
	// calculate the resolution of the image
	unsigned short width;
	unsigned short height;

	// read the header of the input image and copy it to the output image
	if ( pixel_precision_flag == PIXEL_PRECISION_8_BITS )
	{
		// Must be BMP file
		FILE *fh = NULL;

		errno_t	err = fopen_s( &fh, file_path, "rb" );
		if ( err )
			throw Exception(  "Error while opening Src file " + std::string( file_path ) );

		// read the header of the BMP image in order to determine the resolution.
		if ( fread( header, 1, PIC_HEADER_LENGTH, fh) != PIC_HEADER_LENGTH ) 
			throw Exception(  "Error while reading Src header " + std::string( file_path ) );

		fclose( fh );

		width = abs(*(short *)&header[18]);
		height = abs(*(short *)&header[22]);
	}
	else
	{
		width = m_width_16bit;
		height = m_height_16bit;
	}


	threadswidth	=  ceil( (width / BLOCK_SIZE_WIDTH) ); 
	threadsheight	=  ceil( (height / BLOCK_SIZE_HEIGHT) ); 
	kernel_args.threadswidth = threadswidth;
	kernel_args.threadsheight = threadsheight;

	in_surf_args->height = height;
	in_surf_args->width = width;
	in_surf_args->size = 4 * height * width;
	in_surf_args->surface_type = CM_SURFACE_FORMAT_A8R8G8B8;

	if ( pixel_precision_flag == PIXEL_PRECISION_16_BITS )
	{
		in_surf_args->size *= 2;
		in_surf_args->surface_type = CM_SURFACE_FORMAT_A16B16G16R16;
		in_surf_args->element_size = ELEMENT_SIZE_WORD;
	}

	in_surf_args->kernel_arg_indx = 1;

	if ( pixel_precision_flag == PIXEL_PRECISION_8_BITS  )
	{
		in_surf_args->flags = RGB_2_RGBA;
		in_surf_args->flags |=  INVERSE;
		in_surf_args->offset = PIC_HEADER_LENGTH;		/*< skip the header when reading 
														from the file			 >*/
	}

	j = kernel_args.num_media_surface_info;
	kernel_args.num_media_surface_info += 1;
	kernel_args.media_surface[j].kernel_arg_indx = 2;

	int tmp1 = (int)(height + (m_Ver_Block_Size-1))/m_Ver_Block_Size;
	kernel_args.media_surface[j].height = tmp1*m_Ver_Block_Size;
	int tmp2 = (int)(width + (m_Hor_Block_Size-1))/m_Hor_Block_Size;
	kernel_args.media_surface[j].width = tmp2*m_Hor_Block_Size;

	kernel_args.media_surface[j].size = 4 * kernel_args.media_surface[j].height 
		* kernel_args.media_surface[j].width;
	kernel_args.media_surface[j].surface_type = CM_SURFACE_FORMAT_A8R8G8B8;

	if ( pixel_precision_flag == PIXEL_PRECISION_16_BITS )
	{
		/* 
		* Currently the HW doesn't support write to 16 bits surface,
		* define the output as 8 bits with twice the width
		*/
		kernel_args.media_surface[j].size *= 2;
		//kernel_args.media_surface[j].width *= 2;
		kernel_args.media_surface[j].width *=  4;
		kernel_args.media_surface[j].element_size = ELEMENT_SIZE_WORD;
		//kernel_args.media_surface[j].surface_type = CM_SURFACE_FORMAT_A8B8G8R8;
		kernel_args.media_surface[j].surface_type = CM_SURFACE_FORMAT_V8U8; //CM_SURFACE_FORMAT_R16_SINT;

	}	


	if ( pixel_precision_flag == PIXEL_PRECISION_8_BITS  )
	{
		kernel_args.media_surface[j].flags = RGBA_2_RGB;
		kernel_args.media_surface[j].flags |=  INVERSE;
	}
	/*	
	*	for the output we don't need to specifie offset because the 
	*	new data will be appended to the rnd of file
	*/


	if ( pixel_precision_flag == PIXEL_PRECISION_8_BITS  )
	{
		FILE* fh = NULL;

		// The output resolution might be different from the input (must be multiplication of block size)
		unsigned short* out_width = (unsigned short *)& header[18];
		unsigned short* out_height = (unsigned short *)& header[22];
		*out_width = kernel_args.media_surface[j].width;
		*out_height = kernel_args.media_surface[j].height;

		// write the header to the output file
		int err = fopen_s( & fh, kernel_args.media_surface[j].file_path, "wb" );
		if ( err )
			throw Exception( "Error while opening dst file " 
			+ std::string(kernel_args.media_surface[j].file_path) );

		if ( fwrite( header, 1, PIC_HEADER_LENGTH, fh) != PIC_HEADER_LENGTH ) 
			throw Exception( "Error while writing source header " 
			+ std::string(kernel_args.media_surface[j].file_path) );
		fclose( fh );
	}


	uint num_blocks_horizontal = ceil( width / (m_Hor_Block_Size + 0.0f) );
	uint num_blocks_vertical = ceil( height / (m_Ver_Block_Size + 0.0f) );
	uint num_records_stats = 1; //GLC mode
	if (ctrl_mode)
	{
		num_blocks_vertical *= 3; 
		//	num_records_stats = 3;
	}

	// dump the red
	TAvsMsg* drvNormTable_red = new TAvsMsg[num_blocks_horizontal * num_blocks_vertical]; 
	assert( drvNormTable_red );
	j = kernel_args.num_media_surface_info;
	//first_kernel_args_debug = j;
	kernel_args.num_media_surface_info += 1;
	kernel_args.media_surface[j].direction = BUFFER_DIRECTION_INPUT;
	kernel_args.media_surface[j].height = num_blocks_vertical;
	kernel_args.media_surface[j].width = num_blocks_horizontal  * (sizeof(TAvsMsg) / sizeof(float));	
	kernel_args.media_surface[j].size = num_blocks_horizontal  * sizeof(TAvsMsg) * num_blocks_vertical ;
	kernel_args.media_surface[j].surface_type = CM_SURFACE_FORMAT_R32F;
	kernel_args.media_surface[j].kernel_arg_indx = 3;//11;
	kernel_args.media_surface[j].host_buff = drvNormTable_red;
	kernel_args.media_surface[j].file_path = "samplerParams.bin";


	StatisticsMsg* samplStats = new StatisticsMsg[1];
	//TAvsMsg* drvNormTable_red = new TAvsMsg[num_blocks_horizontal * num_blocks_vertical]; 
	assert( samplStats );
	j = kernel_args.num_kernel_buffers;
	//first_kernel_args_debug = j;
	kernel_args.num_kernel_buffers = 1;
	kernel_args.kernel_buffers[j].size = sizeof(StatisticsMsg);	
	kernel_args.kernel_buffers[j].kernel_arg_indx = 4;//12;
	kernel_args.kernel_buffers[j].offset = 0;
	kernel_args.kernel_buffers[j].direction = BUFFER_DIRECTION_INPUT;
	kernel_args.kernel_buffers[j].host_buff = samplStats;
	kernel_args.kernel_buffers[j].file_path = "samplStats.bin";



	// Set CURBE data
	unsigned short* curbe_height = (unsigned short*)malloc( sizeof(unsigned short) );
	assert( curbe_height );
	*curbe_height = height;

	j = kernel_args.num_curbe_data;
	kernel_args.num_curbe_data += 1;
	kernel_args.curbe_args[j].size = sizeof(unsigned short);
	kernel_args.curbe_args[j].kernel_arg_indx = 5;
	kernel_args.curbe_args[j].pData = curbe_height;

	unsigned short* curbe_width = (unsigned short*)malloc( sizeof(unsigned short) );
	assert( curbe_width );
	*curbe_width = width;

	j = kernel_args.num_curbe_data;
	kernel_args.num_curbe_data += 1;
	kernel_args.curbe_args[j].size = sizeof(unsigned short);
	kernel_args.curbe_args[j].kernel_arg_indx = 6;
	kernel_args.curbe_args[j].pData = curbe_width;

	unsigned short* curbe_ctrl_mode = (unsigned short*)malloc( sizeof(short) );
	assert( curbe_ctrl_mode );
	*curbe_ctrl_mode = ctrl_mode;			

	j = kernel_args.num_curbe_data;
	kernel_args.num_curbe_data += 1;
	kernel_args.curbe_args[j].size = sizeof(short);
	kernel_args.curbe_args[j].kernel_arg_indx = 7;
	kernel_args.curbe_args[j].pData = curbe_ctrl_mode;

	unsigned char* curbe_block_size = (unsigned char*)malloc( sizeof(char) );
	assert( curbe_block_size );
	*curbe_block_size = block_size_flag;			

	j = kernel_args.num_curbe_data;
	kernel_args.num_curbe_data += 1;
	kernel_args.curbe_args[j].size = sizeof(char);
	kernel_args.curbe_args[j].kernel_arg_indx = 8;
	kernel_args.curbe_args[j].pData = curbe_block_size;

	unsigned char* curbe_pixel_precision = (unsigned char*)malloc( sizeof(unsigned char) );
	assert( curbe_pixel_precision );
	*curbe_pixel_precision = pixel_precision_flag;

	j = kernel_args.num_curbe_data;
	kernel_args.num_curbe_data += 1;
	kernel_args.curbe_args[j].size = sizeof(unsigned char);
	kernel_args.curbe_args[j].kernel_arg_indx = 9;
	kernel_args.curbe_args[j].pData = curbe_pixel_precision;

	unsigned short* curbe_overw_alpha = (unsigned short*)malloc( sizeof(short) );
	assert( curbe_overw_alpha );
	*curbe_overw_alpha = overwr_alpha;		

	j = kernel_args.num_curbe_data;
	kernel_args.num_curbe_data += 1;
	kernel_args.curbe_args[j].size = sizeof(unsigned short);
	kernel_args.curbe_args[j].kernel_arg_indx = 10;
	kernel_args.curbe_args[j].pData = curbe_overw_alpha;

	unsigned short* curbe_alpha_value = (unsigned short*)malloc( sizeof(short) );
	assert( curbe_alpha_value );
	*curbe_alpha_value = alpha_value;			

	j = kernel_args.num_curbe_data;
	kernel_args.num_curbe_data += 1;
	kernel_args.curbe_args[j].size = sizeof(short);
	kernel_args.curbe_args[j].kernel_arg_indx = 11;
	kernel_args.curbe_args[j].pData = curbe_alpha_value;

	unsigned short* curbe_scaling = (unsigned short*)malloc( sizeof(short) );
	assert( curbe_scaling );
	*curbe_scaling = scaling_enable;			

	j = kernel_args.num_curbe_data;
	kernel_args.num_curbe_data += 1;
	kernel_args.curbe_args[j].size = sizeof(short);
	kernel_args.curbe_args[j].kernel_arg_indx = 12;
	kernel_args.curbe_args[j].pData = curbe_scaling;

	float* curbe_norm_center_x = (float*)malloc( sizeof(float) );
	assert( curbe_norm_center_x );
	*curbe_norm_center_x = TEST_VAL_NORM_CENTER_X;

	j = kernel_args.num_curbe_data;
	kernel_args.num_curbe_data += 1;
	kernel_args.curbe_args[j].size = sizeof(float);
	kernel_args.curbe_args[j].kernel_arg_indx = 13;
	kernel_args.curbe_args[j].pData = curbe_norm_center_x;

	float* curbe_norm_center_y = (float*)malloc( sizeof(float) );
	assert( curbe_norm_center_y );
	*curbe_norm_center_y = TEST_VAL_NORM_CENTER_Y;

	j = kernel_args.num_curbe_data;
	kernel_args.num_curbe_data += 1;
	kernel_args.curbe_args[j].size = sizeof(float);
	kernel_args.curbe_args[j].kernel_arg_indx = 14;
	kernel_args.curbe_args[j].pData = curbe_norm_center_y;

	// set sampler8x8 parameters
	j = kernel_args.num_samplers8x8_args;
	kernel_args.num_samplers8x8_args += 1;

	sampler8x8_info_t* sampler_args = & kernel_args.samplers8x8_args[j];

	sampler_args->kernel_arg_indx = 0;

	memset( & sampler_args->AvsStateMsg, 0, sizeof(CM_AVS_STATE_MSG) );
	memset( & sampler_args->AvsState,	 0, sizeof(CM_AVS_NONPIPLINED_STATE) );

	// config AVS 
	sampler_args->samplerStateDescr.stateType = CM_SAMPLER8X8_AVS;			// AVS
	sampler_args->AvsStateMsg.AVSTYPE = false;								//true nearest, false adaptive	
	sampler_args->AvsStateMsg.BypassIEF = 1;								// ignored for BWL, moved to sampler8x8 payload.
	sampler_args->AvsStateMsg.GainFactor = 44;								// B-spec default
	sampler_args->AvsStateMsg.GlobalNoiseEstm = 255;						// B-spec default
	sampler_args->AvsStateMsg.StrongEdgeThr = 8;							// B-spec default
	sampler_args->AvsStateMsg.WeakEdgeThr = 1;								// B-spec default
	sampler_args->AvsStateMsg.StrongEdgeWght = 7;							// B-spec default
	sampler_args->AvsStateMsg.RegularWght = 2;								// B-spec default
	sampler_args->AvsStateMsg.NonEdgeWght = 1;								// B-spec default
	// 01: Enable 8-tap Adaptive filter on G-channel. 4-tap filter on other channels. 
	sampler_args->AvsStateMsg.EightTapAFEnable	= true;	


	//SKL mode only to be set when AVS msg sequence is 4x4 or 8x4
	if ( block_size_flag & (AVS_BLOCK_SIZE_8x4 | AVS_BLOCK_SIZE_4x4) )
		sampler_args->AvsStateMsg.ShuffleOutputWriteback = true;
	else
		sampler_args->AvsStateMsg.ShuffleOutputWriteback = false;

	sampler_args->AvsState.BypassXAF = 1;								// Disable X adaptive filtering
	sampler_args->AvsState.BypassYAF = 1;								// Disable Y adaptive filtering
	sampler_args->AvsState.maxDerivative4Pixels = 4;
	sampler_args->AvsState.transitionArea4Pixels = 7;
	sampler_args->AvsState.maxDerivative8Pixels = 20;
	sampler_args->AvsState.transitionArea8Pixels = 5;
	//	sampler_args->AvsState.DefaultSharpLvl = 255;			// shoudl make the AVS use the sharp filter	
	sampler_args->AvsState.DefaultSharpLvl = 0;				// should make the AVS use the bilinear 


}

#ifdef DEBUG
void dump_sampler_args_to_file( void* mem, 
	const char* file_name, 
	ushort num_blocks_horizontal, 
	ushort num_blocks_vertical )
{
	assert( mem );
	assert( file_name );

	TAvsMsg* drvNormTable = (TAvsMsg*)mem; 

	// Dump the offsets to a file
	std::ofstream outfile ( file_name );
	outfile << std::setprecision(10);
	outfile << std::fixed;
	for(unsigned int i = 0; i < num_blocks_vertical; ++i)
	{
		for( unsigned int j = 0; j < num_blocks_horizontal; ++j)		
		{
			outfile<< "i: " << i << "\tj: " << j;
			outfile<< "\tx0: " << drvNormTable[(i*num_blocks_horizontal)+j].x0;

			outfile<< "\t\tdx: " << drvNormTable[(i*num_blocks_horizontal)+j].dx;

			outfile<< "\ty0: " << drvNormTable[(i*num_blocks_horizontal)+j].y0;
			outfile<< "\t\tdy: " << drvNormTable[(i*num_blocks_horizontal)+j].dy;

			outfile<< std::endl;
		}
	}

	outfile.close();

}
#endif

// ============================================================================================>



// ======================================================================================>
//
//				This part use the host temaplate - nothing should be changed here
//
// ======================================================================================>
int main (int argc, char * argv[])
{
#ifdef CMRT_EMU
	std::cout<< "Application is running in emulation mode" << std::endl;
#else
	std::cout<< "Application is running in HW mode" << std::endl;
#endif

	device_context_t			device_context;
	kernel_args_t				kernel_args;

	// initialize the device context and kernel args
	memset( & device_context, 0, sizeof(device_context) );
	memset( & kernel_args, 0, sizeof(kernel_args) );

	// Parse arguments	
	parse_arguments( argc, argv, kernel_args );

	// set the program name - where the kernels are located
	device_context.program_path = ISA_FILE_NAME;

	// mark the name of the requested kernel from the program
	kernel_args.kernel_name = CM_KERNEL_FUNCTION(camera_pipe);

	try
	{
		prepare_kernel_args( kernel_args );

		// Create a CM Device
		create_device_context( device_context );

		// TODO: remove this code when the CM team fix the issue with CM_KERNEL_FUNCTION2 
		// Create a kernel	
		if ( ! kernel_args.kernel_name )
			throw Exception("Error: Kernel name wasn't specified!");
		int result = device_context.pCmDev->CreateKernel( device_context.program, 
			CM_KERNEL_FUNCTION(camera_pipe) , 
			kernel_args.kernel ); 
		if (result != CM_SUCCESS ) 
			throw Exception( "CM CreateKernel error"  );

		// Create a kernel for calculation
		create_kernel( device_context, kernel_args );

		// create surfaces for the kernel
		alloc_media_surfaces( device_context, kernel_args );

		// create buffers for the kernel
		alloc_bueffrs ( device_context, kernel_args );

		// write the data from the host buffers to the kernel's CM buffers
		write_data_to_2D_surface( kernel_args );

		// write the data from the host buffers to the kernel's 1D CM buffers
		write_data_to_1D_buffer( kernel_args );

		init_kernel_samplers( device_context, kernel_args );
		init_kernel_samplers8x8( device_context, kernel_args );
		// init the curbe data
		set_kernel_curbe_data( kernel_args );

		// start the task
		start_kernel_task( device_context, kernel_args );

		// retreive the results



		retrieve_result(device_context, kernel_args );

#ifdef DEBUG
		dump_sampler_args_to_file(	kernel_args.media_surface[1].pSysMemSrc,
			"sampler_args_scaling.txt",
			kernel_args.media_surface[1].width /  (sizeof(TAvsMsg) / sizeof(float)),
			kernel_args.media_surface[1].height );
#endif

	}
	//
	catch ( Exception & e )
	{
		std::cerr<< e.what() << std::endl;

		release_kernel_resources( device_context, kernel_args );

		release_device_resources( device_context );

		std::cerr<< "Press Enter key to continue..." << std::endl;
		getchar(); // wait for input from the user so he will be able to read the error message

		return EXIT_FAILURE;
	}

	release_kernel_resources( device_context, kernel_args );

	release_device_resources( device_context );

	return EXIT_SUCCESS;
}

