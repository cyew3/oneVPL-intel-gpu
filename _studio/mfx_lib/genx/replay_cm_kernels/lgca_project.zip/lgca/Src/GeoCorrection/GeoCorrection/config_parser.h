/**             
***
*** Copyright  (C) 1985-2012 Intel Corporation. All rights reserved.
***
*** The information and source code contained herein is the exclusive
*** property of Intel Corporation. and may not be disclosed, examined
*** or reproduced in whole or in part without explicit written authorization
*** from the company.
***
*** ----------------------------------------------------------------------------
**/ 

#ifndef __CONFIG_PARSER_H_
#define __CONFIG_PARSER_H_

#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>      // std::setprecision

#include "host.h"

inline float get_val( std::string& line )
{

	std::string::size_type found;

	found = line.find("=");
	if ( found ==  std::string::npos )
	{
		std::cerr<< "Error: no value of parameter: " << line << std::endl;
		std::cerr<< "\n\nPress Enter key to continue..." << std::endl;
		getchar();	// wait for input from user so he will be able to read the error message
		exit( EXIT_FAILURE );
	}

	
	std::string val = line.substr(found + 1);

	return std::stof (val);;
}

void parse_configuration_file(	const char*			file_path,
								vector<float, 4>&	r_coeff,
								vector<float, 4>&	g_coeff,
								vector<float, 4>&	b_coeff )
{
	assert( file_path );

	std::cout<< "\nParsing configuration file: " << file_path << std::endl;
	std::ifstream ifs ( file_path , std::ifstream::in );

	std::string line;

	while (ifs.good())
	{
		std::getline (ifs,line);

		if ( line.find_first_of("//") !=  std::string::npos || ! line.length() )
			// comment line
			continue;

		// red coefficients
		if ( line.find("red_channel_a") !=  std::string::npos )
			r_coeff[0] = get_val(line);
		else if ( line.find("red_channel_b") !=  std::string::npos )
			r_coeff[1] = get_val(line);
		else if ( line.find("red_channel_c") !=  std::string::npos )
			r_coeff[2] = get_val(line);
		else if ( line.find("red_channel_d") !=  std::string::npos )
			r_coeff[3] = get_val(line);


		// green coefficients
		else if ( line.find("green_channel_a") !=  std::string::npos )
			g_coeff[0] = get_val(line);
		else if ( line.find("green_channel_b") !=  std::string::npos )
			g_coeff[1] = get_val(line);
		else if ( line.find("green_channel_c") !=  std::string::npos )
			g_coeff[2] = get_val(line);
		else if ( line.find("green_channel_d") !=  std::string::npos )
			g_coeff[3] = get_val(line);


		// blue coefficients
		else if ( line.find("blue_channel_a") !=  std::string::npos )
			b_coeff[0] = get_val(line);
		else if ( line.find("blue_channel_b") !=  std::string::npos )
			b_coeff[1] = get_val(line);
		else if ( line.find("blue_channel_c") !=  std::string::npos )
			b_coeff[2] = get_val(line);
		else if ( line.find("blue_channel_d") !=  std::string::npos )
			b_coeff[3] = get_val(line);

		else
		{
			std::cerr<< "Error: unknown parameter in configuration file: " << line << std::endl;
			std::cerr<< "\n\nPress Enter key to continue..." << std::endl;
			getchar();	// wait for input from user so he will be able to read the error message
			exit( EXIT_FAILURE );
		}
		
	}

	ifs.close();
}

#endif // __CONFIG_PARSER_H_