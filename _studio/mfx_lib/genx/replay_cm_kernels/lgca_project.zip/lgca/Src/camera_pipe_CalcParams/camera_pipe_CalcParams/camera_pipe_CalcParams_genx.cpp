/*===================== begin_copyright_notice ==================================

INTEL CONFIDENTIAL
Copyright 2012-2014
Intel Corporation All Rights Reserved.

The source code contained or described herein and all documents related to the
source code ("Material") are owned by Intel Corporation or its suppliers or
licensors. Title to the Material remains with Intel Corporation or its suppliers
and licensors. The Material contains trade secrets and proprietary and confidential
information of Intel or its suppliers and licensors. The Material is protected by
worldwide copyright and trade secret laws and treaty provisions. No part of the
Material may be used, copied, reproduced, modified, published, uploaded, posted,
transmitted, distributed, or disclosed in any way without Intel�s prior express
written permission.

No license under any patent, copyright, trade secret or other intellectual
property right is granted to or conferred upon you by disclosure or delivery
of the Materials, either expressly, by implication, inducement, estoppel or
otherwise. Any license under such intellectual property rights must be express
and approved by Intel in writing.

======================= end_copyright_notice ==================================*/

// Comment to remove debug instructions
//#define DEBUG

#include <cm/cm.h>
#include <cm/genx_sampler.h>

#define CHANNEL_A					3
#define CHANNEL_R					2
#define CHANNEL_G					1
#define CHANNEL_B					0


#define CHANNEL_A_16BIT				3
#define CHANNEL_B_16BIT				2
#define CHANNEL_G_16BIT				1
#define CHANNEL_R_16BIT				0

#define BLOCK_SIZE_WIDTH			16
#define BLOCK_SIZE_HEIGHT			16

#define PIXEL_PRECISION_16_BITS		(1<<0)
#define PIXEL_PRECISION_8_BITS		(1<<1)

#define NUM_ELEMENT_PIXEL			(4)

// location of the coefficients in the vector
#define U0						0
#define DU						1
#define DDU						2

#define V0						3
#define DV						4
#define DDV						5

#define MAX(a,b)				(((a)>(b))? (a) : (b))
#define MIN(a,b)				(((a)<(b))? (a) : (b))




_GENX_  void 
write_sampler_arguements(	SurfaceIndex		dst_surf,
								vector<float,6>		sampler_args,
								uint				h_pos,
								uint				v_pos )
{
	write( dst_surf, h_pos * 24, v_pos, sampler_args );
}


_GENX_  void 
inline  calc_sampler_coordinates(
									ushort					width,	// width of input image
									ushort					height,	// height of input image
									vector<float, 3>		coeff,	// a,b,c,d coefficients 
									ushort					x_pos,	
									ushort					y_pos,
									ushort					m_Hor_Block_Size,
									ushort					m_Ver_Block_Size,
									const float				m_norm_xc,
									const float				m_norm_yc,
									vector_ref<float, 6>	args,
									ushort scaling,
									vector_ref<float, 4> max_min  )	
{
	const float a = coeff[0];
	const float b = coeff[1]; 
	const float c = coeff[2]; 
	const float d = 1-a-b-c;

	// Vertical
	float y0 = 0.0f; 
	float delta = 1.0f;   // (1 / Vertical Scale Factor)	

	//float scaleFactor  = 1.0f / delta;

	// normalized linear step size - perform in 2 steps to minimize differences with GRITS
	float linDY = 0;

	// linDX = m_DeltaU
	linDY = delta / height;

	float linDY_f = (float)linDY;	

	//Lens correction -- currently only utilize linear mode
	// TODO: remove the cm_abs - workaround for compiler issue
	float xc = cm_abs<float>(width * m_norm_xc);	// principal point - X coordinate
	float yc = cm_abs<float>(height * m_norm_yc);	// principal point - Y coordinate
	//const float norm_factor = (xc > yc) ? xc : yc;   //!!check c-model: norm_factor = HWSqrt(float(srcLength_width/2 * srcLength_width/2) + (srcLength_height/2) * (srcLength_height/2));

	float norm_factor = cm_sqrt<float>((width/2 * width/2) + (height/2) * (height/2));
	int middle_pnt = (int)m_Ver_Block_Size >> 1;

	float grid_dx_to_xc = (float)x_pos - xc;
	float grid_dy_to_yc = (float)y_pos - yc;
	float next_grid_dy_to_yc = grid_dy_to_yc + m_Ver_Block_Size;

	//float middle_grid_dy_to_yc = (float)y_pos + middle_pnt - yc; 

	float tmp_num = (float)(grid_dx_to_xc * grid_dx_to_xc);
	tmp_num	+= (float)(grid_dy_to_yc * grid_dy_to_yc);
	float norm_dist = cm_sqrt(tmp_num)* cm_inv(norm_factor);

	tmp_num = (float)(grid_dx_to_xc * grid_dx_to_xc);
	tmp_num	+= (float)(next_grid_dy_to_yc * next_grid_dy_to_yc);
	float next_norm_dist = cm_sqrt(tmp_num) * cm_inv(norm_factor);

	float norm_dist_2 = (float)(norm_dist * norm_dist);
	float norm_dist_3 = (float)(norm_dist_2 * norm_dist);

	float next_norm_dist_2 = (float)(next_norm_dist * next_norm_dist);
	float next_norm_dist_3 = (float)(next_norm_dist_2 * next_norm_dist);

	float tmp_num_1 = a * norm_dist_3;
	float tmp_num_2 = b * norm_dist_2;
	float tmp_num_3 = c * norm_dist;

	float tmp_num_5 = tmp_num_1;
	tmp_num_5 += tmp_num_2;
	tmp_num_5 += tmp_num_3;
	tmp_num_5 += d;
	float LC_scaling_factor = tmp_num_5;

	tmp_num_1 = a * next_norm_dist_3;
	tmp_num_2 = b * next_norm_dist_2;
	tmp_num_3 = c * next_norm_dist;

	tmp_num_5 = tmp_num_1;
	tmp_num_5 += tmp_num_2;
	tmp_num_5 += tmp_num_3;
	tmp_num_5 += d;
	float next_LC_scaling_factor = tmp_num_5;
	
	int accum_2nd_derivative_interval = 0;
	#pragma unroll
	for(int k = 0; k < (middle_pnt+1); k++)
		accum_2nd_derivative_interval += (k*k);

	float tmp_num_4 = (next_LC_scaling_factor - LC_scaling_factor);  //float tmp2 in c-model

	float tmp = m_Ver_Block_Size;

	float sf_derivative = tmp_num_4 * cm_inv(tmp);


	// y0 is v0
	tmp_num_1 = (float)(y_pos * linDY);
	tmp_num_2 = (float)((y0 + tmp_num_1) - m_norm_xc);
	tmp_num_2 *= LC_scaling_factor;	
	args[V0] = tmp_num_2 + m_norm_xc; //normTable[i + (j*vectorLength)].y0

	tmp_num_1 = sf_derivative * grid_dy_to_yc;
	tmp_num_2 = LC_scaling_factor + tmp_num_1;
	tmp_num_3 = (float)(linDY_f * tmp_num_2);
	args[DV] = tmp_num_3;	//! normTable[i + (j*vectorLength)].dy
	//	args[DV] = (float)(linDY_f * (LC_scaling_factor + sf_derivative*grid_dy_to_yc));


	args[DDV] = 0.0f;	// not much difference adding ddv	c-model: normTable[i + (j*vectorLength)].ddy
	
	// Horizontal
	float x0 = 0; 
	delta = 1.0f;   // (1 / horizontal Scale Factor)

	//scaleFactor  = 1.0 / delta;

	//normalized linear step size - perform in 2 steps to minimize differences with GRITS
	// YT: 11/18/2009 -- Use direct SF input or use DeltaU
	float linDX = 0;

	linDX = (float)(delta / width);

	float linDX_f = (float)linDX;

	middle_pnt = (int)m_Hor_Block_Size >> 1;		// the conter of the block

	//float middle_grid_dx_to_xc = (float)x_pos + middle_pnt - xc;
	float next_grid_dx_to_xc = (float)(x_pos + m_Hor_Block_Size) - xc;
	//norm_dist calculated in Vertical
	tmp_num = (float)(next_grid_dx_to_xc * next_grid_dx_to_xc);
	tmp_num	+= (float)(grid_dy_to_yc * grid_dy_to_yc);//!check yc/yx with c-model
	next_norm_dist = cm_sqrt(tmp_num) * cm_inv(norm_factor);

	next_norm_dist_2 = next_norm_dist * next_norm_dist;
	next_norm_dist_3 = next_norm_dist_2 * next_norm_dist;


	//! check LC_scaling_factor for norm_dist
	tmp_num_1 = a * next_norm_dist_3;
	tmp_num_2 = b * next_norm_dist_2;
	tmp_num_3 = c * next_norm_dist;

	tmp_num_5 = tmp_num_1;
	tmp_num_5 += tmp_num_2;
	tmp_num_5 += tmp_num_3;
	tmp_num_5 += d;
	next_LC_scaling_factor = 0;
	next_LC_scaling_factor = tmp_num_5;

	accum_2nd_derivative_interval = 0;
	#pragma unroll
	for(int k = 0; k < (middle_pnt+1); k++)
		accum_2nd_derivative_interval += (k*k);

	tmp_num_4 = (next_LC_scaling_factor - LC_scaling_factor); //tmp in c-model

	tmp = m_Hor_Block_Size;

	sf_derivative = tmp_num_4 * cm_inv(tmp);

	// x0 is u0
	tmp_num_1 = (float)(x_pos * linDX);
	tmp_num_2 = (float)((x0 + tmp_num_1) - m_norm_xc);
	tmp_num_2 *= LC_scaling_factor;	
	
	args[U0] = tmp_num_2 + m_norm_xc;  //! normTable[(i*vectorLength)+j].x0

	tmp_num_1 = sf_derivative * grid_dx_to_xc;
	tmp_num_2 = LC_scaling_factor + tmp_num_1;
	tmp_num_3 = (double)linDX_f * tmp_num_2;
	args[DU] = tmp_num_3; //! normTable[(i*vectorLength)+j].dx
	args[DDU] = 0.0f;	 //!normTable[(i*vectorLength)+j].ddx

	if(scaling)
	{
		if(norm_dist <= 1.0f)
		{
			
			max_min[0] = args[V0] + args[DV]*(m_Ver_Block_Size-1);	//max_y0
			max_min[1] = args[U0] + args[DU]*(m_Hor_Block_Size-1);	//max_x0
			max_min[2] = args[V0];									//min_y0	
			max_min[3] = args[U0];									//min_x0
		}
	}

}

/*--------------------------------------------------------------------------
 * CalcParams kernel - main 
 *
 * Description:
 * 
 *		Kernel that performs sampler parameters and Sampler statistics calculation for the 
 *		lens correction and chroma aberration.
 *
 * Parameters:
 *
 *	SamplerIndex sample_params:			Index of sampler parameters surface for output
 *
 *	SurfaceIndex sample_statistics:		Index of Sampler statistics surface for output
 *
 *
 *	ushort	height:						Input image height [pixel]	
 *	ushort	width:						Input image width  [pixel]
 *
 *  ushort	correction_type:			1 -	CA:  separate coefficients are applied to each of the color channels 
 *										0 -	GLC: in this case the first set of coefficients are applied to all color 
 *										channels

 *	uchar	block_size:					Block size to be used by the AVS Sampler.
 *											�	16x4:		1				(default)
 *											�	8x4:		2
 *											�	4x4:		4
 *	float   norm_dist_center_X:			The position of the principal point relative to the width of the image ( 0 - 1.0)
 *									
 * float   norm_dist_center_Y:			The position of the principal point relative to the height of the image ( 0 - 1.0)
 *
 *	vector<float,3> r_coeff
 *	vector<float,3> g_coeff
 *	vector<float,3> b_coeff:			The coefficients for the correction.
 *										Red, Green and Blue channels respectively.	
 *
 * ushort		scaling					apply scaling factor calculation. If scaling equel to zero,  
 *										sampler statistics surface should not be written
 * Returns:    N/A
 *
 *--------------------------------------------------------------------------*/

extern "C" _GENX_MAIN_ void CalcParams(
									SurfaceIndex		sample_params,
									SurfaceIndex		sample_statistics,
									ushort				height,
									ushort				width,
									ushort				correction_type,
									uchar				block_size,
									float				norm_dist_center_X, // R1.5					- offset 52
									float				norm_dist_center_Y, // R1.6					- offset 56
																			// R1.7					- offset 60 
									vector<float,3>		r_coeff,
									vector<float,3>		g_coeff,
									vector<float,3>		b_coeff,
									ushort				scaling
									)
{
	vector<float,6> r_sampler_args;
	vector<float,6> g_sampler_args;
	vector<float,6> b_sampler_args;

	vector<float,4> max_min_values;

	/* 
	 * Pay attention we use the values of the bit field in order to calculate the width.
	 * This is not a good practice but save couple of instructions. 
	 * In case the values of the bit field "block_size" are changed - one should make sure this
	 * piece of code is correct. 
	 */
	ushort blockWidth = 16 / block_size;
	const ushort blockHeight = 4; // all the supported blocks has height of 4

	ushort numBlockWidth = BLOCK_SIZE_WIDTH / blockWidth;
	const ushort numBlockHeight = BLOCK_SIZE_HEIGHT / blockHeight; // all the supported blocks has height of 4

	uint g_offset = ((height / blockHeight) + 1)>>1;
	g_offset <<= 1;
		
	uint h_pos = get_thread_origin_x();
	uint v_pos = get_thread_origin_y();

	vector< uint, 8 > vec_offsets_atomic_write;
	#pragma unroll
	for(int i=0; i<8; i++)
		vec_offsets_atomic_write(i) = i;

	vector< int, 8 > max_values = 1000000000;
	vector< int, 8 > min_values = 0;
	vector< int, 8 > max_return;
	vector< int, 8 > min_return;

	if((h_pos == 0) && (v_pos == 0))
	{
		write( sample_statistics, 0, max_values );
		write( sample_statistics, 32, min_values );
	}

	for ( uint i = 0; i < numBlockHeight; ++i )	// all the supported blocks has height of 4
	{
		for( uint j = 0; j < numBlockWidth; ++j )
		{
			uint x_pos = (h_pos * BLOCK_SIZE_WIDTH) + (j * blockWidth);
			uint y_pos = (v_pos * BLOCK_SIZE_HEIGHT) + (i * blockHeight);
			
			if(y_pos > height)
				continue;

			max_min_values.select<2,1>(0) = 1;
			max_min_values.select<2,1>(2) = 0;

			calc_sampler_coordinates( width, height, r_coeff, x_pos, y_pos, blockWidth, blockHeight, norm_dist_center_X, 
				norm_dist_center_Y, r_sampler_args, scaling, max_min_values );
			
			//update red or combined channel staistics
			max_values[0] = (int)(max_min_values[0]*1000000000);		//max_y0 
			max_values[1] = (int)(max_min_values[1]*1000000000);		//max_x0
			min_values[0] = (int)(max_min_values[2]*1000000000);		//min_y0
			min_values[1] = (int)(max_min_values[3]*1000000000);		//min_x0
	
			write_sampler_arguements(	sample_params,	r_sampler_args, x_pos / blockWidth, y_pos / blockHeight ); 
			if(correction_type)
			{
				calc_sampler_coordinates( width, height, g_coeff, x_pos, y_pos, blockWidth, blockHeight, 
					norm_dist_center_X, norm_dist_center_Y, g_sampler_args, scaling, max_min_values );

				write_sampler_arguements(	sample_params, g_sampler_args, x_pos / blockWidth, y_pos / blockHeight + g_offset);

				//update green channel staistics
				max_values[2] = (int)(max_min_values[0]*100000000);		//max_y0 
				max_values[3] = (int)(max_min_values[1]*100000000);		//max_x0
				min_values[2] = (int)(max_min_values[2]*100000000);		//min_y0	
				min_values[3] = (int)(max_min_values[3]*100000000);		//min_x0
	

				calc_sampler_coordinates( width, height, b_coeff, x_pos, y_pos, blockWidth, blockHeight, 
					norm_dist_center_X, norm_dist_center_Y, b_sampler_args, scaling, max_min_values );
				write_sampler_arguements(	sample_params,	b_sampler_args, (x_pos / blockWidth), (y_pos / blockHeight)+ g_offset*2); 

				//update blue channel staistics
				max_values[4] = (int)(max_min_values[0]*100000000);		//max_y0 
				max_values[5] = (int)(max_min_values[1]*100000000);		//max_x0
				min_values[4] = (int)(max_min_values[2]*100000000);		//min_y0
				min_values[5] = (int)(max_min_values[3]*100000000);		//min_x0

			}

			if(scaling)
			{
	
				write( sample_statistics, ATOMIC_MAXSINT, 0, vec_offsets_atomic_write, max_values, max_return );
				write( sample_statistics, ATOMIC_MINSINT, 8, vec_offsets_atomic_write, min_values, min_return );
			}

		}
	}
}



